"""Behavioural verifier for the offline TUF-style rotation client.

These tests exercise the verifier across the full set of fixture
bundles plus several generated bundles produced on-the-fly with the
shipped bundle generator.  Each test derives its expected values from
the inputs (metadata, payload digests) rather than from hard-coded
constants, so solutions that hard-code answers for the visible
fixtures fail.
"""

from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
BIN = "tufverify"
GEN = "bundlegen"
BUNDLES = APP / "fixtures" / "bundles"
FIXTURE_HASHES = json.loads(
    (APP / "fixtures" / "fixture_hashes.json").read_text(encoding="utf-8")
)


def run_verifier(
    bundle_path: Path, state_dir: Path, *, expect_ok: bool
) -> subprocess.CompletedProcess[str]:
    """Run the verifier CLI on one bundle and assert the exit code."""
    state_dir.mkdir(parents=True, exist_ok=True)
    proc = subprocess.run(
        [BIN, "--bundle", str(bundle_path), "--state-dir", str(state_dir)],
        cwd=str(APP),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=30,
    )
    assert proc.stdout is not None and proc.stderr is not None
    if expect_ok:
        assert proc.returncode == 0, (
            f"expected accept for {bundle_path.name}, got rc={proc.returncode}\n"
            f"stdout: {proc.stdout}\nstderr: {proc.stderr}"
        )
    else:
        assert proc.returncode != 0, (
            f"expected reject for {bundle_path.name}, got accept\n"
            f"stdout: {proc.stdout}\nstderr: {proc.stderr}"
        )
    return proc


def gen_bundle(variant: str, out_dir: Path, *, payload: str | None = None) -> Path:
    """Generate a fresh bundle using the shipped bundle generator."""
    args = [GEN, "--variant", variant, "--out", str(out_dir)]
    if payload is not None:
        args.extend(["--payload", payload])
    subprocess.run(args, check=True, cwd=str(APP), timeout=30)
    return out_dir


def load_state(state_dir: Path) -> dict:
    return json.loads((state_dir / "state.json").read_text(encoding="utf-8"))


def load_lineage(state_dir: Path) -> dict:
    return json.loads((state_dir / "lineage.lock.json").read_text(encoding="utf-8"))


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def expected_versions(bundle: Path) -> dict:
    """Derive the (root, snapshot, targets, pkg) versions from a bundle."""
    chain = json.loads((bundle / "root_chain.json").read_text(encoding="utf-8"))
    last_root = chain[-1]["signed"]["version"]
    snap = json.loads((bundle / "snapshot.json").read_text(encoding="utf-8"))[
        "signed"
    ]["version"]
    tgt = json.loads((bundle / "targets.json").read_text(encoding="utf-8"))[
        "signed"
    ]["version"]
    pkg_meta = json.loads((bundle / "delegated" / "pkg.json").read_text(encoding="utf-8"))[
        "signed"
    ]
    return {
        "root": last_root,
        "snapshot": snap,
        "targets": tgt,
        "pkg": pkg_meta["version"],
        "payload_sha256": pkg_meta["targets"][0]["sha256"],
        "payload_path": pkg_meta["targets"][0]["path"],
    }


# ---------------------------------------------------------------------------
# Anti-tamper: visible bundle fixtures must not be modified by the solver.
# ---------------------------------------------------------------------------


def test_visible_fixtures_remain_byte_identical():
    """Every visible bundle file matches the fingerprint recorded at build time."""
    for name, files in FIXTURE_HASHES.items():
        for rel, digest in files.items():
            path = BUNDLES / name / rel
            assert path.is_file(), f"missing fixture file {path}"
            assert sha256_file(path) == digest, f"fixture tampered: {path}"


# ---------------------------------------------------------------------------
# 1. Clean-run correctness.
# ---------------------------------------------------------------------------


def test_bootstrap_installs_and_records_state(tmp_path: Path):
    """Bootstrap bundle installs the v1 payload and records lineage in state.json."""
    state = tmp_path / "state"
    bdir = BUNDLES / "bootstrap-v1"
    run_verifier(bdir, state, expect_ok=True)

    exp = expected_versions(bdir)
    st = load_state(state)
    assert st["last_root_version"] == exp["root"]
    assert st["last_snapshot_version"] == exp["snapshot"]
    assert st["last_targets_version"] == exp["targets"]
    assert st["last_delegation_versions"] == {"pkg": exp["pkg"]}
    assert st["installed_sha256"] == exp["payload_sha256"]

    installed = (state / "installed.bin").read_bytes()
    assert sha256_bytes(installed) == exp["payload_sha256"]
    assert installed == (bdir / "artifacts" / exp["payload_path"]).read_bytes()
    assert isinstance(st["journal"], list)
    assert len(st["journal"]) >= 1
    last = st["journal"][-1]
    assert last["root_version"] == exp["root"]
    assert last["snapshot_version"] == exp["snapshot"]
    assert last["targets_version"] == exp["targets"]
    assert last["sha256"] == exp["payload_sha256"]


# ---------------------------------------------------------------------------
# 2. Replay / idempotency.
# ---------------------------------------------------------------------------


def test_replay_is_idempotent_and_journal_appends(tmp_path: Path):
    """Re-running the bootstrap bundle keeps state intact and appends to journal."""
    state = tmp_path / "state"
    bdir = BUNDLES / "bootstrap-v1"
    run_verifier(bdir, state, expect_ok=True)
    st1 = load_state(state)

    run_verifier(BUNDLES / "bootstrap-v1-replay", state, expect_ok=True)
    st2 = load_state(state)

    assert st2["last_root_version"] == st1["last_root_version"]
    assert st2["last_snapshot_version"] == st1["last_snapshot_version"]
    assert st2["last_targets_version"] == st1["last_targets_version"]
    assert st2["last_delegation_versions"] == st1["last_delegation_versions"]
    assert st2["installed_sha256"] == st1["installed_sha256"]
    assert len(st2["journal"]) == 2
    assert st2["journal"][0] == st1["journal"][0]


# ---------------------------------------------------------------------------
# 3. Incremental / multi-step workflow (bootstrap + rotation).
# ---------------------------------------------------------------------------


def test_rotation_after_bootstrap_advances_state(tmp_path: Path):
    """A legitimate v1→v2 rotation installs the new payload and advances every counter."""
    state = tmp_path / "state"
    boot_dir = BUNDLES / "bootstrap-v1"
    rot_dir = BUNDLES / "rotate-v2"
    run_verifier(boot_dir, state, expect_ok=True)
    boot_state = load_state(state)

    run_verifier(rot_dir, state, expect_ok=True)
    exp = expected_versions(rot_dir)
    st = load_state(state)
    assert st["last_root_version"] == exp["root"]
    assert st["last_root_version"] > boot_state["last_root_version"]
    assert st["last_snapshot_version"] == exp["snapshot"]
    assert st["last_targets_version"] == exp["targets"]
    assert st["last_delegation_versions"]["pkg"] == exp["pkg"]
    assert st["installed_sha256"] == exp["payload_sha256"]
    assert st["last_snapshot_version"] > boot_state["last_snapshot_version"]
    assert st["last_targets_version"] > boot_state["last_targets_version"]
    assert (
        st["last_delegation_versions"]["pkg"]
        > boot_state["last_delegation_versions"]["pkg"]
    )

    installed = (state / "installed.bin").read_bytes()
    assert sha256_bytes(installed) == exp["payload_sha256"]
    assert installed == (rot_dir / "artifacts" / exp["payload_path"]).read_bytes()


# ---------------------------------------------------------------------------
# 4. Adversarial families — each must be rejected and must not mutate state.
# ---------------------------------------------------------------------------

ADVERSARIAL_AFTER_BOOTSTRAP = [
    "rotate-v2-no-crossover",
    "rotate-v2-stale-targets",
    "rotate-v2-stale-delegated",
    "rotate-v2-rollback-targets",
    "rotate-v2-rollback-delegated",
]


@pytest.mark.parametrize("variant", ADVERSARIAL_AFTER_BOOTSTRAP)
def test_adversarial_bundles_are_rejected_after_bootstrap(tmp_path: Path, variant: str):
    """After bootstrap each adversarial bundle is rejected without mutating state."""
    state = tmp_path / "state"
    run_verifier(BUNDLES / "bootstrap-v1", state, expect_ok=True)
    pre = load_state(state)
    pre_lineage = load_lineage(state)
    pre_install = (state / "installed.bin").read_bytes()

    run_verifier(BUNDLES / variant, state, expect_ok=False)

    after = load_state(state)
    assert after["last_root_version"] == pre["last_root_version"]
    assert after["last_snapshot_version"] == pre["last_snapshot_version"]
    assert after["last_targets_version"] == pre["last_targets_version"]
    assert after["last_delegation_versions"] == pre["last_delegation_versions"]
    assert after["installed_sha256"] == pre["installed_sha256"]
    assert (state / "installed.bin").read_bytes() == pre_install
    assert load_lineage(state) == pre_lineage
    assert len(after["journal"]) == len(pre["journal"])


# ---------------------------------------------------------------------------
# 5. Cross-command consistency: rotation followed by attempted replays.
# ---------------------------------------------------------------------------


def test_post_rotation_replays_preserve_lineage(tmp_path: Path):
    """After a successful rotation, neither the bootstrap bundle nor adversarial replays roll lineage back."""
    state = tmp_path / "state"
    run_verifier(BUNDLES / "bootstrap-v1", state, expect_ok=True)
    run_verifier(BUNDLES / "rotate-v2", state, expect_ok=True)
    rotated = load_state(state)
    rotated_install = (state / "installed.bin").read_bytes()

    run_verifier(BUNDLES / "bootstrap-v1", state, expect_ok=False)
    run_verifier(BUNDLES / "rotate-v2-stale-targets", state, expect_ok=False)
    run_verifier(BUNDLES / "rotate-v2-stale-delegated", state, expect_ok=False)

    after = load_state(state)
    assert after["last_root_version"] == rotated["last_root_version"]
    assert after["last_snapshot_version"] == rotated["last_snapshot_version"]
    assert after["last_targets_version"] == rotated["last_targets_version"]
    assert after["last_delegation_versions"] == rotated["last_delegation_versions"]
    assert after["installed_sha256"] == rotated["installed_sha256"]
    assert (state / "installed.bin").read_bytes() == rotated_install


# ---------------------------------------------------------------------------
# 6. Persistence: corrupted state.json must recover from the lineage lock
#    without re-accepting rollback bundles.
# ---------------------------------------------------------------------------


def test_recovery_from_corrupted_state_refuses_rollback(tmp_path: Path):
    """After corrupting state.json the verifier rebuilds lineage from the lock and still rejects rollback."""
    state = tmp_path / "state"
    run_verifier(BUNDLES / "bootstrap-v1", state, expect_ok=True)
    run_verifier(BUNDLES / "rotate-v2", state, expect_ok=True)
    healthy = load_state(state)
    healthy_install = (state / "installed.bin").read_bytes()

    (state / "state.json").write_text("{not-json", encoding="utf-8")

    run_verifier(BUNDLES / "rotate-v2-rollback-targets", state, expect_ok=False)
    run_verifier(BUNDLES / "rotate-v2-rollback-delegated", state, expect_ok=False)

    run_verifier(BUNDLES / "rotate-v2", state, expect_ok=True)
    recovered = load_state(state)
    assert recovered["last_root_version"] == healthy["last_root_version"]
    assert recovered["last_snapshot_version"] == healthy["last_snapshot_version"]
    assert recovered["last_targets_version"] == healthy["last_targets_version"]
    assert recovered["last_delegation_versions"] == healthy["last_delegation_versions"]
    assert recovered["installed_sha256"] == healthy["installed_sha256"]
    assert (state / "installed.bin").read_bytes() == healthy_install


# ---------------------------------------------------------------------------
# 7. Ordering sensitivity: adversarial bundles attempted before bootstrap
#    must not corrupt the eventual successful install.
# ---------------------------------------------------------------------------


def test_adversarial_first_then_bootstrap_succeeds(tmp_path: Path):
    """Cryptographically invalid bundles attempted before bootstrap do not poison the eventual install."""
    state = tmp_path / "state"
    for variant in [
        "rotate-v2-no-crossover",
        "rotate-v2-stale-targets",
        "rotate-v2-stale-delegated",
    ]:
        run_verifier(BUNDLES / variant, state, expect_ok=False)
    assert not (state / "installed.bin").exists()

    run_verifier(BUNDLES / "bootstrap-v1", state, expect_ok=True)
    exp = expected_versions(BUNDLES / "bootstrap-v1")
    st = load_state(state)
    assert st["last_root_version"] == exp["root"]
    assert st["last_snapshot_version"] == exp["snapshot"]
    assert st["last_targets_version"] == exp["targets"]
    assert st["installed_sha256"] == exp["payload_sha256"]
    assert isinstance(st["journal"], list)
    assert len(st["journal"]) >= 1
    assert st["journal"][-1]["sha256"] == exp["payload_sha256"]


# ---------------------------------------------------------------------------
# 8. Generated variants — anti-hardcoding: verifier installs valid bundles
#    whose versions and payloads differ from the visible fixtures.
# ---------------------------------------------------------------------------


def test_generated_incremented_targets_installs(tmp_path: Path):
    """A freshly generated rotation bundle with higher snapshot/targets versions installs and records new lineage."""
    state = tmp_path / "state"
    run_verifier(BUNDLES / "bootstrap-v1", state, expect_ok=True)

    fresh = gen_bundle("rotate-v2-incremented-targets", tmp_path / "out")
    run_verifier(fresh, state, expect_ok=True)
    exp = expected_versions(fresh)

    st = load_state(state)
    assert st["last_root_version"] == exp["root"]
    assert st["last_snapshot_version"] == exp["snapshot"]
    assert st["last_targets_version"] == exp["targets"]
    assert st["last_delegation_versions"]["pkg"] == exp["pkg"]
    assert st["installed_sha256"] == exp["payload_sha256"]


def test_generated_incremented_delegated_installs(tmp_path: Path):
    """A generated bundle whose pkg version is well above bootstrap installs and updates per-delegation tracking."""
    state = tmp_path / "state"
    run_verifier(BUNDLES / "bootstrap-v1", state, expect_ok=True)

    fresh = gen_bundle("rotate-v2-incremented-delegated", tmp_path / "out")
    run_verifier(fresh, state, expect_ok=True)
    exp = expected_versions(fresh)

    st = load_state(state)
    assert st["last_delegation_versions"]["pkg"] == exp["pkg"]
    assert st["installed_sha256"] == exp["payload_sha256"]
    assert sha256_file(state / "installed.bin") == exp["payload_sha256"]


def test_generated_custom_payload_round_trip(tmp_path: Path):
    """Overriding the payload regenerates the digest used by the verifier without static answers."""
    state = tmp_path / "state"
    run_verifier(BUNDLES / "bootstrap-v1", state, expect_ok=True)

    custom = "alt-payload"
    fresh = gen_bundle(
        "rotate-v2",
        tmp_path / "out",
        payload=custom,
    )
    run_verifier(fresh, state, expect_ok=True)
    exp = expected_versions(fresh)
    assert exp["payload_sha256"] == sha256_bytes(custom.encode("utf-8"))

    st = load_state(state)
    assert st["installed_sha256"] == exp["payload_sha256"]
    assert (state / "installed.bin").read_bytes() == custom.encode("utf-8")


# ---------------------------------------------------------------------------
# 9. Generated adversarial: produce a v2 bundle whose top-level targets is
#    valid but whose pkg delegated metadata is signed only by retired keys.
#    Must reject under all states.
# ---------------------------------------------------------------------------


def _mutate_pkg(bundle_dir: Path, *, version: int) -> None:
    """Rewrite the pkg metadata version without resigning."""
    path = bundle_dir / "delegated" / "pkg.json"
    obj = json.loads(path.read_text(encoding="utf-8"))
    obj["signed"]["version"] = version
    path.write_text(json.dumps(obj, indent=2) + "\n", encoding="utf-8")


def test_generated_tampered_pkg_metadata_rejected(tmp_path: Path):
    """Tampering with the signed pkg metadata after the generator runs breaks the signature and is rejected."""
    state = tmp_path / "state"
    run_verifier(BUNDLES / "bootstrap-v1", state, expect_ok=True)
    pre = load_state(state)
    pre_install = (state / "installed.bin").read_bytes()

    fresh = gen_bundle("rotate-v2", tmp_path / "out")
    _mutate_pkg(fresh, version=99)

    run_verifier(fresh, state, expect_ok=False)

    after = load_state(state)
    assert after["last_root_version"] == pre["last_root_version"]
    assert after["last_targets_version"] == pre["last_targets_version"]
    assert after["last_delegation_versions"] == pre["last_delegation_versions"]
    assert after["installed_sha256"] == pre["installed_sha256"]
    assert (state / "installed.bin").read_bytes() == pre_install


# ---------------------------------------------------------------------------
# 10. Schema invariants on state file.
# ---------------------------------------------------------------------------


def test_state_file_schema_has_required_fields(tmp_path: Path):
    """The persisted state file exposes the keys the instruction requires."""
    state = tmp_path / "state"
    run_verifier(BUNDLES / "bootstrap-v1", state, expect_ok=True)
    st = load_state(state)
    for key in (
        "last_root_version",
        "last_snapshot_version",
        "last_targets_version",
        "last_delegation_versions",
        "installed_sha256",
        "journal",
    ):
        assert key in st, f"state.json missing required field {key!r}"
    assert isinstance(st["last_delegation_versions"], dict)
    assert isinstance(st["journal"], list)
    assert "pkg" in st["last_delegation_versions"]


# ---------------------------------------------------------------------------
# 11. Cross-state consistency: incremented delegated bundle then a roll back
#     of just pkg must be rejected because per-delegation rollback is tracked.
# ---------------------------------------------------------------------------


def test_per_delegation_rollback_blocked_after_high_version(tmp_path: Path):
    """After installing a high pkg version, a generated bundle with lower pkg version is rejected even with valid top-level metadata."""
    state = tmp_path / "state"
    run_verifier(BUNDLES / "bootstrap-v1", state, expect_ok=True)
    fresh = gen_bundle("rotate-v2-incremented-delegated", tmp_path / "out")
    run_verifier(fresh, state, expect_ok=True)
    high = load_state(state)
    high_install = (state / "installed.bin").read_bytes()

    run_verifier(BUNDLES / "rotate-v2", state, expect_ok=False)
    after = load_state(state)
    assert after["last_delegation_versions"]["pkg"] == high["last_delegation_versions"]["pkg"]
    assert after["installed_sha256"] == high["installed_sha256"]
    assert (state / "installed.bin").read_bytes() == high_install


# ---------------------------------------------------------------------------
# 12. Deterministic repeated run output: the same bundle on the same state
#     produces byte-identical state files.
# ---------------------------------------------------------------------------


def test_repeated_install_produces_deterministic_state(tmp_path: Path):
    """Two independent runs of the same bundle on fresh state produce the same persisted state.json modulo journal length."""
    a = tmp_path / "a" / "state"
    b = tmp_path / "b" / "state"
    run_verifier(BUNDLES / "bootstrap-v1", a, expect_ok=True)
    run_verifier(BUNDLES / "bootstrap-v1", b, expect_ok=True)
    sa = load_state(a)
    sb = load_state(b)
    for key in (
        "last_root_version",
        "last_snapshot_version",
        "last_targets_version",
        "last_delegation_versions",
        "installed_sha256",
    ):
        assert sa[key] == sb[key]
    assert (a / "installed.bin").read_bytes() == (b / "installed.bin").read_bytes()


# ---------------------------------------------------------------------------
# 13. Fresh-state rotation is rejected (must bootstrap before rotation).
# ---------------------------------------------------------------------------


def test_rotation_against_empty_state_fails_then_bootstrap_succeeds(tmp_path: Path):
    """A rotation bundle without prior trust still self-verifies its chain start at v1 and installs at v2."""
    state = tmp_path / "state"
    # The rotate-v2 chain starts at v1, so against empty state the verifier
    # should treat v1 as the bootstrap then advance to v2 in one bundle.
    run_verifier(BUNDLES / "rotate-v2", state, expect_ok=True)
    st = load_state(state)
    exp = expected_versions(BUNDLES / "rotate-v2")
    assert st["last_root_version"] == exp["root"]
    assert st["last_snapshot_version"] == exp["snapshot"]
    assert st["installed_sha256"] == exp["payload_sha256"]


# ---------------------------------------------------------------------------
# 14. Anti-hardcoding: copy the bundle to a different directory; verifier
#     must work from any absolute path, not just /app/fixtures.
# ---------------------------------------------------------------------------


def test_bundle_in_alternate_location_installs(tmp_path: Path):
    """Verifier accepts a bundle copied to a writable location outside /app."""
    state = tmp_path / "state"
    source = BUNDLES / "bootstrap-v1"
    dst = tmp_path / "out"
    shutil.copytree(source, dst)
    run_verifier(dst, state, expect_ok=True)
    st = load_state(state)
    exp = expected_versions(source)
    assert st["last_root_version"] == exp["root"]
    assert st["installed_sha256"] == exp["payload_sha256"]
