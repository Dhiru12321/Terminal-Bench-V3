#!/usr/bin/env bash
set -euo pipefail

OUT="${1:-/app/fixtures/bundles}"
mkdir -p "$OUT"

variants=$(/usr/local/bin/bundlegen --list | sort)
for v in $variants; do
  rm -rf "$OUT/$v"
  /usr/local/bin/bundlegen --variant "$v" --out "$OUT/$v"
done

python3 /app/scripts/fingerprint_fixtures.py "$OUT" > /app/fixtures/fixture_hashes.json
