#!/usr/bin/env python3
"""Fingerprint every file in every generated bundle directory.

The output JSON maps bundle name -> {relative path -> sha256 hex}.  The
verifier test suite uses this file to assert the visible bundles are
unchanged across agent runs so solving by editing bundle inputs is
impossible.
"""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(64 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def fingerprint(root: Path) -> dict[str, dict[str, str]]:
    result: dict[str, dict[str, str]] = {}
    for bundle in sorted(p for p in root.iterdir() if p.is_dir()):
        bundle_hash: dict[str, str] = {}
        for path in sorted(bundle.rglob("*")):
            if path.is_file():
                rel = path.relative_to(bundle).as_posix()
                bundle_hash[rel] = sha256_file(path)
        result[bundle.name] = bundle_hash
    return result


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("usage: fingerprint_fixtures.py <bundles-dir>", file=sys.stderr)
        return 2
    root = Path(argv[1])
    if not root.is_dir():
        print(f"missing bundles dir: {root}", file=sys.stderr)
        return 1
    out = fingerprint(root)
    print(json.dumps(out, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
