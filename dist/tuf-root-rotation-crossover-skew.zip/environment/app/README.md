# tufverify

`tufverify` is a small offline TUF-style update client.  It reads
signed release bundles from disk, walks a root metadata chain
forward from the currently trusted root, and installs delegated
package payloads when their metadata verifies under the chain.

## Layout

| Path                          | Purpose                                                                 |
|-------------------------------|-------------------------------------------------------------------------|
| `cmd/tufverify/`              | CLI entrypoint that the verifier ships as.                              |
| `cmd/bundlegen/`              | Deterministic bundle/key generator used by the fixture suite.           |
| `internal/meta/`              | On-disk JSON metadata structures + canonical encoding for signing.      |
| `internal/crypto/`            | ed25519 helpers and keyid derivation.                                   |
| `internal/state/`             | Persistence of accepted lineage and the lineage lock used for recovery. |
| `internal/verify/`            | Signature/threshold/delegation/rollback verification primitives.        |
| `internal/client/`            | High-level workflow: load bundle, verify, install, persist.             |
| `fixtures/`                   | Pre-built deterministic bundles consumed by tests and the agent.        |
| `scripts/`                    | Build-time helpers (fixture generation, fingerprinting).                |

## Commands

```text
tufverify --bundle <bundle-dir> --state-dir <state-dir>
bundlegen --variant <name> --out <out-dir> [--payload <bytes>]
bundlegen --list
```

Exit codes follow the standard convention: `0` for accepted/installed,
non-zero for rejection (with a short reason on stderr).

## Bundle layout

```text
<bundle>/
├── root_chain.json   # array of signed root metadata, ascending version
├── snapshot.json     # signed snapshot for the chain head
├── targets.json      # signed top-level targets for the chain head
├── delegated/
│   └── pkg.json      # signed delegated metadata for the pkg role
└── artifacts/
    └── pkg/
        └── release.bin
```

## State layout

```text
<state-dir>/
├── state.json
├── lineage.lock.json
├── trusted-root.json
└── installed.bin
```

See `docs/wire-format.md` for the byte-level metadata schema and
`docs/threat-model.md` for the documented attack surface.
