// Command tufverify is the offline TUF-style verifier CLI.
//
// Usage: tufverify --bundle <bundle-dir> --state-dir <state-dir>
//
// Exit codes:
//
//	0  bundle accepted and installed
//	1  bundle rejected; persisted state unchanged
//	2  usage error
package main

import (
	"flag"
	"fmt"
	"os"

	"tufclient/internal/runtime"
)

func main() {
	bundleDir := flag.String("bundle", "", "path to the bundle directory")
	stateDir := flag.String("state-dir", "", "path to the persisted state directory")
	flag.Parse()

	if *bundleDir == "" || *stateDir == "" {
		fmt.Fprintln(os.Stderr, "tufverify: --bundle and --state-dir are required")
		os.Exit(2)
	}

	if err := os.MkdirAll(*stateDir, 0o755); err != nil {
		fmt.Fprintf(os.Stderr, "tufverify: cannot create state dir: %v\n", err)
		os.Exit(1)
	}

	c, st, err := runtime.New(*stateDir)
	if err != nil {
		fmt.Fprintf(os.Stderr, "tufverify: state load: %v\n", err)
		os.Exit(1)
	}

	b, err := runtime.LoadBundle(*bundleDir)
	if err != nil {
		fmt.Fprintf(os.Stderr, "tufverify: bundle load: %v\n", err)
		os.Exit(1)
	}

	if err := c.VerifyAndInstall(b, st); err != nil {
		fmt.Fprintf(os.Stderr, "tufverify: reject: %v\n", err)
		os.Exit(1)
	}
	fmt.Printf("installed root=%d snapshot=%d targets=%d sha256=%s\n",
		st.LastRootVersion, st.LastSnapshotVersion, st.LastTargetsVersion, st.InstalledSHA256)
}
