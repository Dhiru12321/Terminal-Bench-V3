package main

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"fmt"

	"tufclient/internal/meta"
)

// keyFromSeed deterministically derives an ed25519 keypair from a
// textual seed.  The same seed produces the same keys forever, which
// lets bundlegen rebuild byte-identical fixtures on every container
// build.
func keyFromSeed(seed string) (ed25519.PrivateKey, meta.PublicKey) {
	h := sha256.Sum256([]byte("tuf-task::" + seed))
	priv := ed25519.NewKeyFromSeed(h[:])
	pub := priv.Public().(ed25519.PublicKey)
	pubHex := hex.EncodeToString(pub)
	kidSum := sha256.Sum256(pub)
	kid := hex.EncodeToString(kidSum[:16])
	return priv, meta.PublicKey{
		KeyID:  kid,
		Scheme: "ed25519",
		Public: pubHex,
	}
}

// sign returns a hex-encoded ed25519 signature over message using the
// given private key.  It panics on impossible failures because all
// keys are derived from known-good seeds at build time.
func sign(priv ed25519.PrivateKey, message []byte) string {
	if len(priv) != ed25519.PrivateKeySize {
		panic(fmt.Sprintf("bundlegen: bad private key length %d", len(priv)))
	}
	return hex.EncodeToString(ed25519.Sign(priv, message))
}

// keyset names public keys consistently across rotations so callers
// can refer to them by readable seed labels.
type keyset struct {
	priv map[string]ed25519.PrivateKey
	pub  map[string]meta.PublicKey
}

func newKeyset() *keyset {
	return &keyset{
		priv: map[string]ed25519.PrivateKey{},
		pub:  map[string]meta.PublicKey{},
	}
}

func (k *keyset) ensure(seeds ...string) {
	for _, s := range seeds {
		if _, ok := k.priv[s]; ok {
			continue
		}
		priv, pub := keyFromSeed(s)
		k.priv[s] = priv
		k.pub[s] = pub
	}
}

func (k *keyset) keyIDs(seeds ...string) []string {
	out := make([]string, 0, len(seeds))
	for _, s := range seeds {
		out = append(out, k.pub[s].KeyID)
	}
	return out
}

func (k *keyset) keyMap(seeds ...string) map[string]meta.PublicKey {
	out := map[string]meta.PublicKey{}
	for _, s := range seeds {
		pk := k.pub[s]
		out[pk.KeyID] = pk
	}
	return out
}

func (k *keyset) privBySeed(seed string) ed25519.PrivateKey {
	return k.priv[seed]
}

func (k *keyset) idForSeed(seed string) string {
	return k.pub[seed].KeyID
}

// signWith produces a Signature struct for the named seed over the
// given canonical bytes.
func (k *keyset) signWith(seed string, message []byte) meta.Signature {
	priv := k.privBySeed(seed)
	if priv == nil {
		panic(fmt.Sprintf("bundlegen: unknown seed %q", seed))
	}
	return meta.Signature{KeyID: k.idForSeed(seed), Sig: sign(priv, message)}
}

// pubBytes returns the binary public key for a seed (used in unit
// tests and assertions).
func (k *keyset) pubBytes(seed string) []byte {
	raw, _ := hex.DecodeString(k.pub[seed].Public)
	return raw
}

func _u32(n uint32) []byte {
	out := make([]byte, 4)
	binary.BigEndian.PutUint32(out, n)
	return out
}
