package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"tufclient/internal/meta"
)

// bundle bundles every artifact the verifier loads from a bundle dir.
type bundle struct {
	rootChain []meta.RootSigned
	snapshot  meta.SnapshotSigned
	targets   meta.TargetsSigned
	delegated []meta.DelegatedSigned
	payload   []byte
	payloadAt string
}

func (b *bundle) write(dir string) error {
	if err := os.MkdirAll(filepath.Join(dir, "delegated"), 0o755); err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Join(dir, "artifacts"), 0o755); err != nil {
		return err
	}
	if err := writeJSON(filepath.Join(dir, "root_chain.json"), b.rootChain); err != nil {
		return err
	}
	if err := writeJSON(filepath.Join(dir, "snapshot.json"), b.snapshot); err != nil {
		return err
	}
	if err := writeJSON(filepath.Join(dir, "targets.json"), b.targets); err != nil {
		return err
	}
	for _, d := range b.delegated {
		path := filepath.Join(dir, "delegated", fmt.Sprintf("%s.json", d.Signed.Name))
		if err := writeJSON(path, d); err != nil {
			return err
		}
	}
	if b.payload != nil {
		payloadPath := filepath.Join(dir, "artifacts", b.payloadAt)
		if err := os.MkdirAll(filepath.Dir(payloadPath), 0o755); err != nil {
			return err
		}
		if err := os.WriteFile(payloadPath, b.payload, 0o644); err != nil {
			return err
		}
	}
	return nil
}

func writeJSON(path string, v any) error {
	raw, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, append(raw, '\n'), 0o644)
}

// replacePayload swaps the bundle's payload bytes and re-signs the
// affected delegated metadata so the bundle stays internally
// consistent.  Only the pkg delegated target is rewritten because all
// variants ship a single delegated target for the pkg role.
func (b *bundle) replacePayload(ks *keyset, newPayload []byte) {
	b.payload = newPayload
	if len(b.delegated) == 0 {
		panic("bundlegen: cannot replace payload on bundle with no delegated metadata")
	}
	d := &b.delegated[0]
	sum := sha256.Sum256(newPayload)
	if len(d.Signed.Targets) == 0 {
		panic("bundlegen: delegated metadata has no targets to update")
	}
	d.Signed.Targets[0].Length = len(newPayload)
	d.Signed.Targets[0].SHA256 = hex.EncodeToString(sum[:])

	// Re-sign using the original signers.  We recover the signer seeds
	// from the existing signature keyids and the keyset's id->seed map.
	signerSeeds := make([]string, 0, len(d.Signatures))
	idToSeed := map[string]string{}
	for seed, pk := range ks.pub {
		idToSeed[pk.KeyID] = seed
	}
	for _, s := range d.Signatures {
		seed, ok := idToSeed[s.KeyID]
		if !ok {
			panic(fmt.Sprintf("bundlegen: replacement signer keyid %s has no known seed", s.KeyID))
		}
		signerSeeds = append(signerSeeds, seed)
	}

	signedBytes, err := meta.Canonical(d.Signed)
	if err != nil {
		panic(fmt.Sprintf("bundlegen: canonical encode for resign: %v", err))
	}
	d.Signatures = d.Signatures[:0]
	for _, seed := range signerSeeds {
		d.Signatures = append(d.Signatures, ks.signWith(seed, signedBytes))
	}
}
