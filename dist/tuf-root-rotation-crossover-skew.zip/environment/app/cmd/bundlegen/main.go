// Command bundlegen produces deterministic TUF-style fixture bundles
// for the verifier under /app/cmd/tufverify.
//
// Usage: bundlegen --variant <name> --out <dir>
//
// All cryptographic material is derived from textual seeds (see
// keys.go) so re-running the generator produces byte-identical
// output.  This generator is the reference producer for the wire
// format consumed by the runtime tool elsewhere in this repo.
package main

import (
	"flag"
	"fmt"
	"os"
)

func main() {
	variant := flag.String("variant", "", "bundle variant name (see list below)")
	out := flag.String("out", "", "output directory")
	list := flag.Bool("list", false, "print known variants and exit")
	payload := flag.String("payload", "", "override payload bytes (otherwise deterministic per variant)")
	flag.Parse()

	if *list {
		for name := range variants {
			fmt.Println(name)
		}
		return
	}

	if *variant == "" || *out == "" {
		fmt.Fprintln(os.Stderr, "bundlegen: --variant and --out are required (try --list)")
		os.Exit(2)
	}

	fn, ok := variants[*variant]
	if !ok {
		fmt.Fprintf(os.Stderr, "bundlegen: unknown variant %q\n", *variant)
		os.Exit(2)
	}
	ks := newKeyset()
	b := fn(ks)
	if *payload != "" {
		b.replacePayload(ks, []byte(*payload))
	}
	if err := os.MkdirAll(*out, 0o755); err != nil {
		fmt.Fprintf(os.Stderr, "bundlegen: mkdir: %v\n", err)
		os.Exit(1)
	}
	if err := b.write(*out); err != nil {
		fmt.Fprintf(os.Stderr, "bundlegen: write: %v\n", err)
		os.Exit(1)
	}
}
