package main

import (
	"fmt"

	"tufclient/internal/meta"
)

// variants enumerates every bundle the verifier suite knows about.
// Each variant function constructs and returns a complete bundle
// using the supplied keyset.  Variants share key material via the
// keyset so cross-bundle behavior (rotation, replay) is consistent.
var variants = map[string]func(*keyset) *bundle{
	"bootstrap-v1":                    variantBootstrapV1,
	"bootstrap-v1-replay":             variantBootstrapV1Replay,
	"rotate-v2":                       variantRotateV2,
	"rotate-v2-no-crossover":          variantRotateV2NoCrossover,
	"rotate-v2-stale-targets":         variantRotateV2StaleTargets,
	"rotate-v2-stale-delegated":       variantRotateV2StaleDelegated,
	"rotate-v2-rollback-targets":      variantRotateV2RollbackTargets,
	"rotate-v2-rollback-delegated":    variantRotateV2RollbackDelegated,
	"rotate-v2-incremented-targets":   variantRotateV2IncrementedTargets,
	"rotate-v2-incremented-delegated": variantRotateV2IncrementedDelegated,
	"rotate-v2-mixed-pkg":             variantRotateV2MixedPkg,
}

func makeBootstrapPayload() []byte { return []byte("payload-v1\n") }
func makeRotationPayload() []byte  { return []byte("payload-v2-rotated\n") }
func makeBumpedPayload() []byte    { return []byte("payload-v2-bumped\n") }

// variantBootstrapV1 is the initial release: trust v1 root, install
// v1 snapshot/targets/pkg.  Snapshot, targets, and pkg ship at
// version 3 so subsequent rollback scenarios have downward room.
func variantBootstrapV1(ks *keyset) *bundle {
	rootV1 := buildRootV1(ks)
	ks.ensure("pkg-v1-a", "pkg-v1-b")

	targets := buildTargets(ks, targetsParams{
		version:      3,
		targetsSeed:  "targets-v1",
		pkgKeySeeds:  []string{"pkg-v1-a", "pkg-v1-b"},
		pkgThreshold: 1,
	})
	payload := makeBootstrapPayload()
	delegated := buildDelegated(ks, []string{"pkg-v1-a"}, 3, payload, "pkg/release.bin")

	snapshot := buildSnapshot(ks, "snapshot-v1", 3, 3, map[string]int{"pkg": 3})

	return &bundle{
		rootChain: []meta.RootSigned{rootV1},
		snapshot:  snapshot,
		targets:   targets,
		delegated: []meta.DelegatedSigned{delegated},
		payload:   payload,
		payloadAt: "pkg/release.bin",
	}
}

// variantBootstrapV1Replay is identical to the bootstrap bundle and
// is used for idempotent replay tests.
func variantBootstrapV1Replay(ks *keyset) *bundle {
	return variantBootstrapV1(ks)
}

// variantRotateV2 is the legitimate rotation: v1 trusted → bundle
// introduces v2 with crossover signatures.  Snapshot, targets, and
// pkg all advance to version 5 from bootstrap's 3.
func variantRotateV2(ks *keyset) *bundle {
	rootV1 := buildRootV1(ks)
	rootV2 := buildRootV2(ks)

	ks.ensure("pkg-v2-a", "pkg-v2-b")
	targets := buildTargets(ks, targetsParams{
		version:      5,
		targetsSeed:  "targets-v2",
		pkgKeySeeds:  []string{"pkg-v2-a", "pkg-v2-b"},
		pkgThreshold: 1,
	})
	payload := makeRotationPayload()
	delegated := buildDelegated(ks, []string{"pkg-v2-a"}, 5, payload, "pkg/release.bin")
	snapshot := buildSnapshot(ks, "snapshot-v2", 5, 5, map[string]int{"pkg": 5})

	return &bundle{
		rootChain: []meta.RootSigned{rootV1, rootV2},
		snapshot:  snapshot,
		targets:   targets,
		delegated: []meta.DelegatedSigned{delegated},
		payload:   payload,
		payloadAt: "pkg/release.bin",
	}
}

// variantRotateV2NoCrossover keeps the v2 root metadata but drops
// every signature by the v1 root keys, so only v2 self-signs.
func variantRotateV2NoCrossover(ks *keyset) *bundle {
	b := variantRotateV2(ks)
	// rebuild root chain without v1 signatures on v2
	rootV2 := b.rootChain[1]
	filtered := rootV2.Signatures[:0]
	for _, s := range rootV2.Signatures {
		v1KeyIDs := map[string]bool{
			ks.idForSeed("root-v1-a"): true,
			ks.idForSeed("root-v1-b"): true,
			ks.idForSeed("root-v1-c"): true,
		}
		if v1KeyIDs[s.KeyID] {
			continue
		}
		filtered = append(filtered, s)
	}
	rootV2.Signatures = filtered
	b.rootChain[1] = rootV2
	return b
}

// variantRotateV2StaleTargets ships a v2 trust chain alongside a
// targets document at version 4 carrying only signatures from the
// v1-era targets key.
func variantRotateV2StaleTargets(ks *keyset) *bundle {
	rootV1 := buildRootV1(ks)
	rootV2 := buildRootV2(ks)
	ks.ensure("pkg-v1-a", "pkg-v1-b")

	targets := buildTargets(ks, targetsParams{
		version:      4,
		targetsSeed:  "targets-v1",
		pkgKeySeeds:  []string{"pkg-v1-a", "pkg-v1-b"},
		pkgThreshold: 1,
	})

	payload := makeBootstrapPayload()
	delegated := buildDelegated(ks, []string{"pkg-v1-a"}, 4, payload, "pkg/release.bin")
	snapshot := buildSnapshot(ks, "snapshot-v2", 4, 4, map[string]int{"pkg": 4})
	return &bundle{
		rootChain: []meta.RootSigned{rootV1, rootV2},
		snapshot:  snapshot,
		targets:   targets,
		delegated: []meta.DelegatedSigned{delegated},
		payload:   payload,
		payloadAt: "pkg/release.bin",
	}
}

// variantRotateV2StaleDelegated keeps the v2 top-level targets (which
// publishes new pkg keys) but ships pkg metadata carrying signatures
// from the v1-era pkg keys.
func variantRotateV2StaleDelegated(ks *keyset) *bundle {
	b := variantRotateV2(ks)
	ks.ensure("pkg-v1-a", "pkg-v1-b")
	delegated := buildDelegated(ks, []string{"pkg-v1-a"}, 5, b.payload, "pkg/release.bin")
	b.delegated = []meta.DelegatedSigned{delegated}
	return b
}

// variantRotateV2RollbackTargets emits snapshot/targets at version 2
// alongside the v2 root chain.  The bootstrap baseline shipped these
// components at version 3.
func variantRotateV2RollbackTargets(ks *keyset) *bundle {
	rootV1 := buildRootV1(ks)
	rootV2 := buildRootV2(ks)

	ks.ensure("pkg-v2-a", "pkg-v2-b")
	targets := buildTargets(ks, targetsParams{
		version:      2,
		targetsSeed:  "targets-v2",
		pkgKeySeeds:  []string{"pkg-v2-a", "pkg-v2-b"},
		pkgThreshold: 1,
	})
	payload := makeBumpedPayload()
	delegated := buildDelegated(ks, []string{"pkg-v2-a"}, 5, payload, "pkg/release.bin")
	snapshot := buildSnapshot(ks, "snapshot-v2", 2, 2, map[string]int{"pkg": 5})

	return &bundle{
		rootChain: []meta.RootSigned{rootV1, rootV2},
		snapshot:  snapshot,
		targets:   targets,
		delegated: []meta.DelegatedSigned{delegated},
		payload:   payload,
		payloadAt: "pkg/release.bin",
	}
}

// variantRotateV2RollbackDelegated advances top-level metadata to 5
// while shipping pkg at version 2, below the bootstrap baseline of 3.
func variantRotateV2RollbackDelegated(ks *keyset) *bundle {
	rootV1 := buildRootV1(ks)
	rootV2 := buildRootV2(ks)

	ks.ensure("pkg-v2-a", "pkg-v2-b")
	targets := buildTargets(ks, targetsParams{
		version:      5,
		targetsSeed:  "targets-v2",
		pkgKeySeeds:  []string{"pkg-v2-a", "pkg-v2-b"},
		pkgThreshold: 1,
	})
	payload := makeRotationPayload()
	delegated := buildDelegated(ks, []string{"pkg-v2-a"}, 2, payload, "pkg/release.bin")
	snapshot := buildSnapshot(ks, "snapshot-v2", 5, 5, map[string]int{"pkg": 2})

	return &bundle{
		rootChain: []meta.RootSigned{rootV1, rootV2},
		snapshot:  snapshot,
		targets:   targets,
		delegated: []meta.DelegatedSigned{delegated},
		payload:   payload,
		payloadAt: "pkg/release.bin",
	}
}

// variantRotateV2IncrementedTargets is the v1→v2 rotation with
// snapshot/targets bumped to version 7 and pkg held at 5.  Used by
// the generated-variant tests to exercise version handling beyond
// the on-disk fixtures.
func variantRotateV2IncrementedTargets(ks *keyset) *bundle {
	rootV1 := buildRootV1(ks)
	rootV2 := buildRootV2(ks)

	ks.ensure("pkg-v2-a", "pkg-v2-b")
	targets := buildTargets(ks, targetsParams{
		version:      7,
		targetsSeed:  "targets-v2",
		pkgKeySeeds:  []string{"pkg-v2-a", "pkg-v2-b"},
		pkgThreshold: 1,
	})
	payload := []byte(fmt.Sprintf("incremented-payload-targets-%d", 7))
	delegated := buildDelegated(ks, []string{"pkg-v2-a"}, 5, payload, "pkg/release.bin")
	snapshot := buildSnapshot(ks, "snapshot-v2", 7, 7, map[string]int{"pkg": 5})
	return &bundle{
		rootChain: []meta.RootSigned{rootV1, rootV2},
		snapshot:  snapshot,
		targets:   targets,
		delegated: []meta.DelegatedSigned{delegated},
		payload:   payload,
		payloadAt: "pkg/release.bin",
	}
}

// variantRotateV2IncrementedDelegated bumps both top-level metadata
// (snap/targets=4) and the delegated metadata (pkg=9) above the
// bootstrap baseline of 3 so the bundle is monotonic and exercises
// per-delegation tracking with a noticeably higher pkg version.
func variantRotateV2IncrementedDelegated(ks *keyset) *bundle {
	rootV1 := buildRootV1(ks)
	rootV2 := buildRootV2(ks)

	ks.ensure("pkg-v2-a", "pkg-v2-b")
	targets := buildTargets(ks, targetsParams{
		version:      4,
		targetsSeed:  "targets-v2",
		pkgKeySeeds:  []string{"pkg-v2-a", "pkg-v2-b"},
		pkgThreshold: 1,
	})
	payload := []byte("incremented-payload-delegated-9")
	delegated := buildDelegated(ks, []string{"pkg-v2-a"}, 9, payload, "pkg/release.bin")
	snapshot := buildSnapshot(ks, "snapshot-v2", 4, 4, map[string]int{"pkg": 9})
	return &bundle{
		rootChain: []meta.RootSigned{rootV1, rootV2},
		snapshot:  snapshot,
		targets:   targets,
		delegated: []meta.DelegatedSigned{delegated},
		payload:   payload,
		payloadAt: "pkg/release.bin",
	}
}

// variantRotateV2MixedPkg signs the pkg metadata with one signature
// each from pkg-v1-a and pkg-v2-a.  The pkg delegation declares
// threshold 1.
func variantRotateV2MixedPkg(ks *keyset) *bundle {
	b := variantRotateV2(ks)
	ks.ensure("pkg-v1-a", "pkg-v1-b")
	delegated := buildDelegated(ks, []string{"pkg-v1-a", "pkg-v2-a"}, 2, b.payload, "pkg/release.bin")
	b.delegated = []meta.DelegatedSigned{delegated}
	return b
}
