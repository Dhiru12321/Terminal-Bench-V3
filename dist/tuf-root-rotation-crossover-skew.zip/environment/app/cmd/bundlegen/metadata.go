package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"

	"tufclient/internal/meta"
)

// buildRootV1 returns the canonical v1 root metadata as published by
// the offline signing ceremony.  It lists three "root" keys with a
// threshold of 2, one targets key, one snapshot key, and signs the
// metadata with the v1 root keys.
func buildRootV1(ks *keyset) meta.RootSigned {
	ks.ensure(
		"root-v1-a", "root-v1-b", "root-v1-c",
		"targets-v1", "snapshot-v1",
	)
	root := meta.Root{
		Type:    "root",
		Version: 1,
		Expires: "2099-01-01T00:00:00Z",
		Keys:    map[string]meta.PublicKey{},
		Roles: map[string]meta.Role{
			"root": {
				KeyIDs:    ks.keyIDs("root-v1-a", "root-v1-b", "root-v1-c"),
				Threshold: 2,
			},
			"snapshot": {
				KeyIDs:    ks.keyIDs("snapshot-v1"),
				Threshold: 1,
			},
			"targets": {
				KeyIDs:    ks.keyIDs("targets-v1"),
				Threshold: 1,
			},
		},
	}
	for _, s := range []string{"root-v1-a", "root-v1-b", "root-v1-c", "targets-v1", "snapshot-v1"} {
		k := ks.pub[s]
		root.Keys[k.KeyID] = k
	}
	signed, _ := meta.Canonical(root)
	rs := meta.RootSigned{Signed: root}
	rs.Signatures = []meta.Signature{
		ks.signWith("root-v1-a", signed),
		ks.signWith("root-v1-b", signed),
	}
	return rs
}

// buildRootV2 returns the v2 root after an offline rotation that
// replaces every key with a fresh seed.  The metadata is signed with
// crossover signatures (keys from both v1 and v2 root roles) so that
// a strict client can validate the rotation against both root role
// specifications.
func buildRootV2(ks *keyset) meta.RootSigned {
	ks.ensure(
		"root-v2-a", "root-v2-b", "root-v2-c",
		"targets-v2", "snapshot-v2",
	)
	root := meta.Root{
		Type:    "root",
		Version: 2,
		Expires: "2099-01-01T00:00:00Z",
		Keys:    map[string]meta.PublicKey{},
		Roles: map[string]meta.Role{
			"root": {
				KeyIDs:    ks.keyIDs("root-v2-a", "root-v2-b", "root-v2-c"),
				Threshold: 2,
			},
			"snapshot": {
				KeyIDs:    ks.keyIDs("snapshot-v2"),
				Threshold: 1,
			},
			"targets": {
				KeyIDs:    ks.keyIDs("targets-v2"),
				Threshold: 1,
			},
		},
	}
	for _, s := range []string{"root-v2-a", "root-v2-b", "root-v2-c", "targets-v2", "snapshot-v2"} {
		k := ks.pub[s]
		root.Keys[k.KeyID] = k
	}
	signed, _ := meta.Canonical(root)
	rs := meta.RootSigned{Signed: root}
	rs.Signatures = []meta.Signature{
		ks.signWith("root-v1-a", signed),
		ks.signWith("root-v1-c", signed),
		ks.signWith("root-v2-a", signed),
		ks.signWith("root-v2-b", signed),
	}
	return rs
}

// buildSnapshot constructs a snapshot metadata document at the given
// version that references the given targets and delegated versions.
func buildSnapshot(ks *keyset, snapSeed string, version, targetsVersion int, delegatedVersions map[string]int) meta.SnapshotSigned {
	s := meta.Snapshot{
		Type:    "snapshot",
		Version: version,
		Expires: "2099-01-01T00:00:00Z",
		Meta: map[string]int{
			"targets.json": targetsVersion,
		},
	}
	for name, v := range delegatedVersions {
		s.Meta[fmt.Sprintf("delegated/%s.json", name)] = v
	}
	signed, _ := meta.Canonical(s)
	ss := meta.SnapshotSigned{Signed: s}
	ss.Signatures = []meta.Signature{ks.signWith(snapSeed, signed)}
	return ss
}

type targetsParams struct {
	version       int
	targetsSeed   string
	pkgKeySeeds   []string
	pkgThreshold  int
	includeTarget bool
}

// buildTargets builds the top-level targets metadata and declares a
// single delegation named "pkg" with the supplied key seeds.
func buildTargets(ks *keyset, p targetsParams) meta.TargetsSigned {
	pkgKeyIDs := ks.keyIDs(p.pkgKeySeeds...)
	pkgKeys := ks.keyMap(p.pkgKeySeeds...)

	t := meta.Targets{
		Type:    "targets",
		Version: p.version,
		Expires: "2099-01-01T00:00:00Z",
		Targets: []meta.Target{},
		Delegations: []meta.Delegation{
			{
				Name:      "pkg",
				KeyIDs:    pkgKeyIDs,
				Threshold: p.pkgThreshold,
				Keys:      pkgKeys,
				Paths:     []string{"pkg/*"},
			},
		},
	}
	signed, _ := meta.Canonical(t)
	ts := meta.TargetsSigned{Signed: t}
	ts.Signatures = []meta.Signature{ks.signWith(p.targetsSeed, signed)}
	return ts
}

// buildDelegated produces signed delegated metadata for a single
// target payload.
func buildDelegated(ks *keyset, signerSeeds []string, version int, payload []byte, payloadPath string) meta.DelegatedSigned {
	sum := sha256.Sum256(payload)
	d := meta.Delegated{
		Type:    "delegated",
		Name:    "pkg",
		Version: version,
		Expires: "2099-01-01T00:00:00Z",
		Targets: []meta.Target{
			{
				Path:   payloadPath,
				Length: len(payload),
				SHA256: hex.EncodeToString(sum[:]),
			},
		},
	}
	signed, _ := meta.Canonical(d)
	ds := meta.DelegatedSigned{Signed: d}
	for _, s := range signerSeeds {
		ds.Signatures = append(ds.Signatures, ks.signWith(s, signed))
	}
	return ds
}
