module tufclient

go 1.21
