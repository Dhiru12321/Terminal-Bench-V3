# Wire Format

Every metadata document is a JSON object with two top-level keys:

```json
{
  "signed":     { /* role-specific signed payload */ },
  "signatures": [ {"keyid": "...", "sig": "<hex>"}, ... ]
}
```

`signed` is the payload protected by the signatures.  The signature
input is the canonical encoding produced by
`internal/meta.Canonical()`: sorted map keys, no whitespace, integers
as decimal, strings as JSON strings.  Both `tufverify` and `bundlegen`
use the same encoder so signatures round-trip exactly.

## Root

```json
{
  "_type":   "root",
  "version": <int>,
  "expires": "<RFC3339 timestamp>",
  "keys":    { "<keyid>": {"keyid": "<keyid>", "scheme": "ed25519", "public": "<hex>"}, ... },
  "roles": {
    "root":     {"keyids": ["..."], "threshold": <int>},
    "snapshot": {"keyids": ["..."], "threshold": <int>},
    "targets":  {"keyids": ["..."], "threshold": <int>}
  }
}
```

Root metadata authorizes the next root version (crossover signing)
and every other top-level role for as long as it is the trusted root.

## Snapshot

```json
{
  "_type":   "snapshot",
  "version": <int>,
  "expires": "<RFC3339>",
  "meta":    { "targets.json": <int>, "delegated/<name>.json": <int>, ... }
}
```

`meta` declares the versions the snapshot pins for the top-level
targets and every delegated metadata document.

## Targets

```json
{
  "_type":   "targets",
  "version": <int>,
  "expires": "<RFC3339>",
  "targets": [ {"path": "...", "length": <int>, "sha256": "<hex>"} ],
  "delegations": [
    {
      "name":      "pkg",
      "keyids":    ["..."],
      "threshold": <int>,
      "keys":      {"<keyid>": {...}},
      "paths":     ["pkg/*"]
    }
  ]
}
```

The top-level targets document publishes the delegation table that
the next layer uses to verify delegated metadata.

## Delegated

```json
{
  "_type":   "delegated",
  "name":    "pkg",
  "version": <int>,
  "expires": "<RFC3339>",
  "targets": [ {"path": "...", "length": <int>, "sha256": "<hex>"} ]
}
```

## Keyids

A keyid is the lowercase hex encoding of the first 16 bytes of
`SHA-256(public_key_bytes)`.  Public key bytes are the raw 32 bytes
of the ed25519 public key.
