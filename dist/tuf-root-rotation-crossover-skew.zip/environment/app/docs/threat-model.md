# Threat Model

`tufverify` runs as a fully offline tool.  Bundles arrive on disk
and are authenticated against state persisted from previous runs.
Network access is not part of the trust model.

## Attacker capabilities

The attacker can:

- Replace any bundle directory on disk between invocations.
- Construct arbitrary new metadata signed by any keys they hold.
- Hold individual ed25519 keys, but key custody is bounded by the
  operator's distribution policy.

## Out of scope

- Confidentiality of metadata at rest (everything is signed but not
  encrypted).
- Sybil attacks on keys (operators are responsible for key
  generation hygiene).
- Side-channel attacks on the host running the tool.
- Network-level adversaries — the tool never talks to the network.

## Operational notes

Bundle bytes are not encrypted; signatures are the only authenticity
mechanism.  The lineage lock at `lineage.lock.json` is a
defence-in-depth record that lets the tool reconstruct its trust
state if the primary state file is lost or corrupted.
