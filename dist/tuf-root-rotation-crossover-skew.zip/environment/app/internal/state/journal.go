package state

// CopyEvents returns a deep copy of the journal so callers can mutate
// their own slice without disturbing the persisted state.
func CopyEvents(in []Event) []Event {
	out := make([]Event, len(in))
	for i, e := range in {
		out[i] = e
		if e.DelegationVersions != nil {
			cv := make(map[string]int, len(e.DelegationVersions))
			for k, v := range e.DelegationVersions {
				cv[k] = v
			}
			out[i].DelegationVersions = cv
		}
	}
	return out
}

// LastEvent returns the most recently appended event, or nil when the
// journal is empty.
func LastEvent(in []Event) *Event {
	if len(in) == 0 {
		return nil
	}
	e := in[len(in)-1]
	return &e
}
