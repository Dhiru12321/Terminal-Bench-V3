// Package state persists the verifier's lineage across runs.
//
// state.json contains the last accepted versions and installed
// artifact digest plus an append-only journal of accepted installs.
//
// lineage.lock.json stores the last-known-good lineage so that a
// corrupted state.json can be repaired without weakening the rollback
// invariants.
package state

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
)

type Event struct {
	RootVersion        int            `json:"root_version"`
	SnapshotVersion    int            `json:"snapshot_version"`
	TargetsVersion     int            `json:"targets_version"`
	DelegationVersions map[string]int `json:"delegation_versions"`
	SHA256             string         `json:"sha256"`
}

type State struct {
	LastRootVersion        int            `json:"last_root_version"`
	LastSnapshotVersion    int            `json:"last_snapshot_version"`
	LastTargetsVersion     int            `json:"last_targets_version"`
	LastDelegationVersions map[string]int `json:"last_delegation_versions"`
	InstalledSHA256        string         `json:"installed_sha256"`
	Journal                []Event        `json:"journal"`
}

type LineageLock struct {
	LastRootVersion        int            `json:"last_root_version"`
	LastSnapshotVersion    int            `json:"last_snapshot_version"`
	LastTargetsVersion     int            `json:"last_targets_version"`
	LastDelegationVersions map[string]int `json:"last_delegation_versions"`
}

func statePath(dir string) string   { return filepath.Join(dir, "state.json") }
func lineagePath(dir string) string { return filepath.Join(dir, "lineage.lock.json") }

// Load returns the persisted state.  A missing state file is treated
// as a clean bootstrap.  A corrupted state file falls back to the
// lineage lock if one is present so the rollback invariants are
// preserved across recovery.
func Load(dir string) (*State, error) {
	raw, err := os.ReadFile(statePath(dir))
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return emptyState(), nil
		}
		return nil, err
	}
	st := emptyState()
	if jerr := json.Unmarshal(raw, st); jerr != nil {
		lock, lerr := loadLineage(dir)
		if lerr != nil {
			return nil, fmt.Errorf("state corrupt and no lineage lock: %w", jerr)
		}
		st = emptyState()
		st.LastRootVersion = lock.LastRootVersion
		st.LastSnapshotVersion = lock.LastSnapshotVersion
		st.LastTargetsVersion = lock.LastTargetsVersion
		st.LastDelegationVersions = copyVersions(lock.LastDelegationVersions)
	}
	if st.LastDelegationVersions == nil {
		st.LastDelegationVersions = map[string]int{}
	}
	if st.Journal == nil {
		st.Journal = []Event{}
	}
	return st, nil
}

func loadLineage(dir string) (*LineageLock, error) {
	raw, err := os.ReadFile(lineagePath(dir))
	if err != nil {
		return nil, err
	}
	lock := &LineageLock{}
	if err := json.Unmarshal(raw, lock); err != nil {
		return nil, err
	}
	if lock.LastDelegationVersions == nil {
		lock.LastDelegationVersions = map[string]int{}
	}
	return lock, nil
}

// Save writes state.json and the matching lineage lock atomically
// from the caller's perspective: state first, then lineage lock.
func Save(dir string, st *State) error {
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	out, err := json.MarshalIndent(st, "", "  ")
	if err != nil {
		return err
	}
	if err := os.WriteFile(statePath(dir), append(out, '\n'), 0o644); err != nil {
		return err
	}
	lock := LineageLock{
		LastRootVersion:        st.LastRootVersion,
		LastSnapshotVersion:    st.LastSnapshotVersion,
		LastTargetsVersion:     st.LastTargetsVersion,
		LastDelegationVersions: copyVersions(st.LastDelegationVersions),
	}
	rawLock, err := json.MarshalIndent(lock, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(lineagePath(dir), append(rawLock, '\n'), 0o644)
}

func emptyState() *State {
	return &State{
		LastDelegationVersions: map[string]int{},
		Journal:                []Event{},
	}
}

func copyVersions(in map[string]int) map[string]int {
	out := make(map[string]int, len(in))
	for k, v := range in {
		out[k] = v
	}
	return out
}
