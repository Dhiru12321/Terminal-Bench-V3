package audit

import (
	"errors"
	"fmt"

	"tufclient/internal/meta"
)

// ErrRollback signals that a bundle attempts to install metadata at a
// lower version than what is already persisted in state.
var ErrRollback = errors.New("rollback detected")

// RollbackState is the subset of persisted state that rollback
// checking depends on.
type RollbackState struct {
	LastRootVersion        int
	LastSnapshotVersion    int
	LastTargetsVersion     int
	LastDelegationVersions map[string]int
}

// CheckRollback compares the incoming bundle's metadata versions
// against the persisted lineage and returns an error when any
// tracked component would move backward relative to the last
// installed value.
func CheckRollback(
	state RollbackState,
	newRootVersion int,
	snapshot meta.Snapshot,
	targets meta.Targets,
	delegated []meta.Delegated,
) error {
	if state.LastRootVersion == 0 {
		return nil
	}
	if newRootVersion != state.LastRootVersion {
		return nil
	}
	if snapshot.Version < state.LastSnapshotVersion {
		return fmt.Errorf("%w: snapshot version %d < persisted %d",
			ErrRollback, snapshot.Version, state.LastSnapshotVersion)
	}
	if targets.Version < state.LastTargetsVersion {
		return fmt.Errorf("%w: targets version %d < persisted %d",
			ErrRollback, targets.Version, state.LastTargetsVersion)
	}
	for _, d := range delegated {
		prev := state.LastDelegationVersions[d.Name]
		if d.Version < prev {
			return fmt.Errorf("%w: delegation %q version %d < persisted %d",
				ErrRollback, d.Name, d.Version, prev)
		}
	}
	return nil
}
