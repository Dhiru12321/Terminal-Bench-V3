package audit

import (
	"encoding/json"
	"errors"
	"fmt"

	"tufclient/internal/meta"
)

var (
	jsonMarshal   = json.Marshal
	jsonUnmarshal = json.Unmarshal
)

// ErrUnknownDelegation is returned when the delegated metadata names a
// role that is not present in the active delegation table.
var ErrUnknownDelegation = errors.New("unknown delegation")

// DelegationTable indexes delegations by role name for fast lookup
// when verifying delegated metadata.
type DelegationTable struct {
	roles map[string]meta.Delegation
}

// BuildDelegationTable indexes the delegations published in the given
// top-level targets document.
func BuildDelegationTable(t meta.Targets) *DelegationTable {
	table := &DelegationTable{roles: map[string]meta.Delegation{}}
	for _, d := range t.Delegations {
		table.roles[d.Name] = d
	}
	return table
}

// MergeNew copies entries from other into the receiver for role
// names not already present.  Existing entries are left untouched.
func (t *DelegationTable) MergeNew(other *DelegationTable) {
	if other == nil {
		return
	}
	if t.roles == nil {
		t.roles = map[string]meta.Delegation{}
	}
	for name, d := range other.roles {
		if _, ok := t.roles[name]; ok {
			continue
		}
		t.roles[name] = d
	}
}

// Lookup returns the delegation entry for the given role name.
func (t *DelegationTable) Lookup(name string) (meta.Delegation, bool) {
	d, ok := t.roles[name]
	return d, ok
}

// MarshalJSON implements json.Marshaler so the table can be persisted
// across runs.
func (t *DelegationTable) MarshalJSON() ([]byte, error) {
	if t == nil {
		return []byte("{}"), nil
	}
	return jsonMarshal(t.roles)
}

// UnmarshalJSON implements json.Unmarshaler for persisted tables.
func (t *DelegationTable) UnmarshalJSON(data []byte) error {
	m := map[string]meta.Delegation{}
	if err := jsonUnmarshal(data, &m); err != nil {
		return err
	}
	t.roles = m
	return nil
}

// VerifyDelegated validates the delegated metadata against the
// supplied delegation entry.  Threshold counting uses the delegation's
// own published key set.
func VerifyDelegated(table *DelegationTable, delegated meta.DelegatedSigned) error {
	d, ok := table.Lookup(delegated.Signed.Name)
	if !ok {
		return fmt.Errorf("%w: %s", ErrUnknownDelegation, delegated.Signed.Name)
	}
	signedBytes, err := meta.Canonical(delegated.Signed)
	if err != nil {
		return fmt.Errorf("delegated canonical encode: %w", err)
	}
	allowed := make(map[string]meta.PublicKey, len(d.KeyIDs))
	for _, kid := range d.KeyIDs {
		if k, ok := d.Keys[kid]; ok {
			allowed[kid] = k
		}
	}
	return VerifyThreshold(signedBytes, delegated.Signatures, allowed, d.Threshold)
}
