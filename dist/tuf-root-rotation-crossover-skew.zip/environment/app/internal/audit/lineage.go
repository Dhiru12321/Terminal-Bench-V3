package audit

import (
	"errors"
	"fmt"

	"tufclient/internal/meta"
)

// ErrRootChain is returned when the supplied root chain cannot be
// walked forward from the currently trusted root in monotonic
// single-step increments.
var ErrRootChain = errors.New("root chain not monotonic")

// ApplyRootChain walks the supplied root metadata documents forward
// from currentTrusted (nil during bootstrap) and returns the final
// accepted root.
//
// The chain must be ordered by ascending version.  Each new chain
// element is verified against the role specification of the new root
// metadata being introduced.  Versions less than or equal to the
// currently trusted version are treated as idempotent re-trust steps
// after self-verification and do not advance the trusted root.
func ApplyRootChain(currentTrusted *meta.Root, chain []meta.RootSigned) (*meta.Root, error) {
	if len(chain) == 0 {
		if currentTrusted == nil {
			return nil, fmt.Errorf("%w: empty chain and no trusted root", ErrRootChain)
		}
		return currentTrusted, nil
	}

	trusted := currentTrusted
	for i, candidate := range chain {
		signedBytes, err := meta.Canonical(candidate.Signed)
		if err != nil {
			return nil, fmt.Errorf("root chain step %d: canonical encode: %w", i, err)
		}

		newRole, ok := candidate.Signed.Roles["root"]
		if !ok {
			return nil, fmt.Errorf("root chain step %d: new root metadata missing 'root' role", i)
		}
		newKeys := allowedKeys(newRole, candidate.Signed.Keys)
		if err := VerifyThreshold(signedBytes, candidate.Signatures, newKeys, newRole.Threshold); err != nil {
			return nil, fmt.Errorf("root chain step %d: self verification failed: %w", i, err)
		}

		if trusted == nil {
			next := candidate.Signed
			trusted = &next
			continue
		}

		if candidate.Signed.Version <= trusted.Version {
			continue
		}
		if candidate.Signed.Version != trusted.Version+1 {
			return nil, fmt.Errorf(
				"%w: chain step %d has version %d, expected up to %d or %d",
				ErrRootChain, i, candidate.Signed.Version, trusted.Version, trusted.Version+1,
			)
		}

		next := candidate.Signed
		trusted = &next
	}
	return trusted, nil
}

// allowedKeys returns the subset of keys mapped by id that the role
// authorizes; callers pass the resulting map straight into
// VerifyThreshold so each accepted signature is by an authorized key.
func allowedKeys(role meta.Role, keys map[string]meta.PublicKey) map[string]meta.PublicKey {
	out := make(map[string]meta.PublicKey)
	for _, kid := range role.KeyIDs {
		if k, ok := keys[kid]; ok {
			out[kid] = k
		}
	}
	return out
}
