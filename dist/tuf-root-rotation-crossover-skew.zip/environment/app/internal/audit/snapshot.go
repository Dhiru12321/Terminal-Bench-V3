package audit

import (
	"fmt"

	"tufclient/internal/meta"
)

// VerifySnapshot validates the snapshot metadata against the active
// root.  The snapshot role is looked up in the active root.  Every
// key id the snapshot is signed by must be authorized by the active
// snapshot role; that filtering happens implicitly because we restrict
// the keys map to the role's keyids before invoking VerifyThreshold.
func VerifySnapshot(active *meta.Root, snap meta.SnapshotSigned) error {
	role, ok := active.Roles["snapshot"]
	if !ok {
		return fmt.Errorf("snapshot role missing from active root")
	}
	keys := allowedKeys(role, active.Keys)
	signedBytes, err := meta.Canonical(snap.Signed)
	if err != nil {
		return fmt.Errorf("snapshot canonical encode: %w", err)
	}
	return VerifyThreshold(signedBytes, snap.Signatures, keys, role.Threshold)
}
