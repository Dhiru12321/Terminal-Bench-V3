package audit

import (
	"fmt"

	"tufclient/internal/meta"
)

// VerifyTargets validates the top-level targets metadata against the
// active root.  The active root publishes which keyids own the targets
// role.  The verifier maintains a key registry that accumulates keys
// seen across root versions; this registry is what we consult when
// counting signatures, regardless of whether the keyid currently
// appears in the active role's keyids list.
func VerifyTargets(active *meta.Root, registry map[string]meta.PublicKey, targets meta.TargetsSigned) error {
	role, ok := active.Roles["targets"]
	if !ok {
		return fmt.Errorf("targets role missing from active root")
	}
	signedBytes, err := meta.Canonical(targets.Signed)
	if err != nil {
		return fmt.Errorf("targets canonical encode: %w", err)
	}
	return VerifyThreshold(signedBytes, targets.Signatures, registry, role.Threshold)
}
