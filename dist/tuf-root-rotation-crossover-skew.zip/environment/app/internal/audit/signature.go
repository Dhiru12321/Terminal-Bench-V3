package audit

import (
	"errors"
	"fmt"

	"tufclient/internal/crypto"
	"tufclient/internal/meta"
)

// ErrThreshold is returned when the number of valid signatures for a
// role does not meet the configured threshold.
var ErrThreshold = errors.New("signature threshold not met")

// VerifyThreshold checks that the given signed bytes are covered by at
// least `threshold` distinct valid signatures issued by keys in
// `keys`.  Each accepted signature is counted at most once per keyid.
//
// Note: this helper does not enforce a role-specific keyid allowlist;
// callers are responsible for restricting `keys` to the keys that the
// active role authorizes before invoking the helper.
func VerifyThreshold(signedBytes []byte, sigs []meta.Signature, keys map[string]meta.PublicKey, threshold int) error {
	seen := map[string]bool{}
	good := 0
	for _, s := range sigs {
		if seen[s.KeyID] {
			continue
		}
		pubMeta, ok := keys[s.KeyID]
		if !ok {
			continue
		}
		pub, err := crypto.DecodePublic(pubMeta.Public)
		if err != nil {
			continue
		}
		sig, err := crypto.DecodeSignature(s.Sig)
		if err != nil {
			continue
		}
		if !crypto.Verify(pub, signedBytes, sig) {
			continue
		}
		seen[s.KeyID] = true
		good++
	}
	if good < threshold {
		return fmt.Errorf("%w: have %d valid signatures, need %d", ErrThreshold, good, threshold)
	}
	return nil
}
