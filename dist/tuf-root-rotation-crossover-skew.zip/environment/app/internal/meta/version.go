package meta

// MaxInt returns the larger of two ints (small helper used by the
// snapshot/targets cross-checks).
func MaxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}

// MinInt returns the smaller of two ints.
func MinInt(a, b int) int {
	if a < b {
		return a
	}
	return b
}
