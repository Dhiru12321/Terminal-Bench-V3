// Package meta defines the on-disk metadata structures used by the
// offline TUF-style client.  The format is a simplified subset of the
// TUF reference specification: every metadata document is a JSON object
// with a "signed" payload and a list of "signatures" attached, signed
// with ed25519 keys whose public material is published in the trusted
// root metadata.
package meta

import (
	"encoding/json"
)

// Role describes the authorization rule for a single named role: which
// key ids are entitled to sign on its behalf and how many distinct
// signatures are required for the metadata to be considered authentic.
type Role struct {
	KeyIDs    []string `json:"keyids"`
	Threshold int      `json:"threshold"`
}

// PublicKey is the ed25519 public material recognised by a particular
// root version.  KeyID is a stable hex-encoded SHA-256 prefix derived
// by the bundle generator from the public bytes.
type PublicKey struct {
	KeyID  string `json:"keyid"`
	Scheme string `json:"scheme"`
	Public string `json:"public"`
}

// Signature is one ed25519 signature over the canonical JSON encoding
// of the "signed" object of its parent metadata document.
type Signature struct {
	KeyID string `json:"keyid"`
	Sig   string `json:"sig"`
}

// Root metadata enumerates the trusted keys and the role specifications
// (key ids + thresholds) for the four roles "root", "snapshot",
// "targets", and the delegation table for "pkg".
type Root struct {
	Type      string               `json:"_type"`
	Version   int                  `json:"version"`
	Expires   string               `json:"expires"`
	Keys      map[string]PublicKey `json:"keys"`
	Roles     map[string]Role      `json:"roles"`
}

type RootSigned struct {
	Signed     Root        `json:"signed"`
	Signatures []Signature `json:"signatures"`
}

// Snapshot lists the verified version of every other top-level
// metadata file in this distribution, including the delegated role
// metadata documents the targets file references.
type Snapshot struct {
	Type    string         `json:"_type"`
	Version int            `json:"version"`
	Expires string         `json:"expires"`
	Meta    map[string]int `json:"meta"`
}

type SnapshotSigned struct {
	Signed     Snapshot    `json:"signed"`
	Signatures []Signature `json:"signatures"`
}

// Delegation describes a named delegated role published inside the
// top-level targets document.  Each delegation lists its own key set
// and threshold so the delegated metadata can be verified
// independently of the top-level keys.
type Delegation struct {
	Name      string               `json:"name"`
	KeyIDs    []string             `json:"keyids"`
	Threshold int                  `json:"threshold"`
	Keys      map[string]PublicKey `json:"keys"`
	Paths     []string             `json:"paths"`
}

// Target lists the published artifact at a relative path.
type Target struct {
	Path   string `json:"path"`
	Length int    `json:"length"`
	SHA256 string `json:"sha256"`
}

// Targets is the top-level targets metadata.  It enumerates published
// artifacts (none here; everything ships via the pkg delegation) and
// the active delegation table for this version.
type Targets struct {
	Type        string       `json:"_type"`
	Version     int          `json:"version"`
	Expires     string       `json:"expires"`
	Targets     []Target     `json:"targets"`
	Delegations []Delegation `json:"delegations"`
}

type TargetsSigned struct {
	Signed     Targets     `json:"signed"`
	Signatures []Signature `json:"signatures"`
}

// Delegated metadata for the "pkg" role.  This is what actually
// publishes the installable artifact in this distribution.
type Delegated struct {
	Type    string   `json:"_type"`
	Name    string   `json:"name"`
	Version int      `json:"version"`
	Expires string   `json:"expires"`
	Targets []Target `json:"targets"`
}

type DelegatedSigned struct {
	Signed     Delegated   `json:"signed"`
	Signatures []Signature `json:"signatures"`
}

// CanonicalBytes returns a deterministic JSON encoding of v for
// signing.  We use Go's encoding/json compact form with sorted map
// keys; the bundle generator and verifier must agree on this exact
// serialization byte-for-byte.
func CanonicalBytes(v any) ([]byte, error) {
	return json.Marshal(v)
}
