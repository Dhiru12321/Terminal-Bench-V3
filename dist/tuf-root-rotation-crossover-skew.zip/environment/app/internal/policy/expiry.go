// Package policy implements small policy checks that bracket the
// cryptographic verification (expiry, recognised types, etc.).
package policy

import (
	"errors"
	"fmt"
	"time"
)

// ErrExpired is returned when metadata is past its expiry timestamp.
var ErrExpired = errors.New("metadata expired")

// IsFresh returns nil when expires is in the future relative to now.
// expires is parsed as RFC3339.  The helper takes time as an argument
// so callers can keep the check time-injectable.
func IsFresh(expires string, now time.Time) error {
	t, err := time.Parse(time.RFC3339, expires)
	if err != nil {
		return fmt.Errorf("expiry parse: %w", err)
	}
	if now.After(t) {
		return fmt.Errorf("%w: expires at %s, now %s", ErrExpired, expires, now.Format(time.RFC3339))
	}
	return nil
}
