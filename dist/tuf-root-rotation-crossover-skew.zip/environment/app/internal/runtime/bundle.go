package runtime

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"

	"tufclient/internal/meta"
)

// Bundle is the on-disk layout the verifier consumes.
//
// A bundle is a directory containing:
//
//   - root_chain.json  (array of RootSigned, ordered by version)
//   - snapshot.json    (SnapshotSigned)
//   - targets.json     (TargetsSigned)
//   - delegated/<role>.json
//   - artifacts/<path>
type Bundle struct {
	Dir       string
	RootChain []meta.RootSigned
	Snapshot  meta.SnapshotSigned
	Targets   meta.TargetsSigned
	Delegated map[string]meta.DelegatedSigned
}

// LoadBundle reads a bundle from disk and returns it in canonical
// ordering (delegated roles sorted by name) so downstream processing
// is deterministic.
func LoadBundle(dir string) (*Bundle, error) {
	b := &Bundle{Dir: dir, Delegated: map[string]meta.DelegatedSigned{}}
	if err := readJSON(filepath.Join(dir, "root_chain.json"), &b.RootChain); err != nil {
		return nil, fmt.Errorf("read root_chain.json: %w", err)
	}
	if err := readJSON(filepath.Join(dir, "snapshot.json"), &b.Snapshot); err != nil {
		return nil, fmt.Errorf("read snapshot.json: %w", err)
	}
	if err := readJSON(filepath.Join(dir, "targets.json"), &b.Targets); err != nil {
		return nil, fmt.Errorf("read targets.json: %w", err)
	}
	delegDir := filepath.Join(dir, "delegated")
	entries, err := os.ReadDir(delegDir)
	if err != nil {
		return nil, fmt.Errorf("read delegated dir: %w", err)
	}
	names := make([]string, 0, len(entries))
	for _, e := range entries {
		if e.IsDir() {
			continue
		}
		names = append(names, e.Name())
	}
	sort.Strings(names)
	for _, name := range names {
		var d meta.DelegatedSigned
		if err := readJSON(filepath.Join(delegDir, name), &d); err != nil {
			return nil, fmt.Errorf("read delegated %s: %w", name, err)
		}
		b.Delegated[d.Signed.Name] = d
	}
	return b, nil
}

// ArtifactPath resolves a target's relative path inside the bundle.
func (b *Bundle) ArtifactPath(t meta.Target) string {
	return filepath.Join(b.Dir, "artifacts", t.Path)
}

func readJSON(path string, into any) error {
	raw, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	return json.Unmarshal(raw, into)
}

// SortedDelegated returns delegated metadata sorted by role name.
func (b *Bundle) SortedDelegated() []meta.DelegatedSigned {
	names := make([]string, 0, len(b.Delegated))
	for n := range b.Delegated {
		names = append(names, n)
	}
	sort.Strings(names)
	out := make([]meta.DelegatedSigned, 0, len(names))
	for _, n := range names {
		out = append(out, b.Delegated[n])
	}
	return out
}

// ErrInvalidBundle is returned when a bundle is missing required parts
// or otherwise malformed before any cryptographic checks happen.
var ErrInvalidBundle = errors.New("invalid bundle")
