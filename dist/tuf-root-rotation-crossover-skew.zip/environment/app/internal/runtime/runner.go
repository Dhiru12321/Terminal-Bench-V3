package runtime

import (
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"os"
	"path/filepath"

	"tufclient/internal/meta"
	"tufclient/internal/state"
	"tufclient/internal/audit"
)

// ErrPayloadMismatch is returned when a delegated target's payload
// does not match the digest published in the verified metadata.
var ErrPayloadMismatch = errors.New("payload digest mismatch")

// Client is the verifier's stateful container.  A single Client is
// constructed per invocation; it loads the persisted state, validates
// the bundle, and applies the install.
type Client struct {
	stateDir string

	trustedRoot *meta.Root

	// keyRegistry tracks every public key the client has seen across
	// trusted roots so that signatures by any historically-known
	// keyid can be looked up without re-reading every root document.
	keyRegistry map[string]meta.PublicKey

	// delegationTable is populated on first targets verification and
	// reused across runs for stable lookup of delegated role specs.
	delegationTable *audit.DelegationTable
}

// New constructs a fresh client and loads persisted state, the
// trusted root checkpoint, and any persisted delegation table.
func New(stateDir string) (*Client, *state.State, error) {
	st, err := state.Load(stateDir)
	if err != nil {
		return nil, nil, err
	}
	c := &Client{
		stateDir:    stateDir,
		keyRegistry: map[string]meta.PublicKey{},
	}
	if path := trustedRootPath(stateDir); fileExists(path) {
		var r meta.Root
		if err := readJSON(path, &r); err != nil {
			return nil, nil, fmt.Errorf("read trusted root: %w", err)
		}
		c.trustedRoot = &r
		for kid, k := range r.Keys {
			c.keyRegistry[kid] = k
		}
	}
	if path := delegationCachePath(stateDir); fileExists(path) {
		table := &audit.DelegationTable{}
		if err := readJSON(path, table); err != nil {
			return nil, nil, fmt.Errorf("read delegation cache: %w", err)
		}
		c.delegationTable = table
	}
	return c, st, nil
}

func trustedRootPath(dir string) string    { return filepath.Join(dir, "trusted-root.json") }
func delegationCachePath(dir string) string {
	return filepath.Join(dir, "delegation-cache.json")
}

func fileExists(path string) bool {
	_, err := os.Stat(path)
	return err == nil
}

// VerifyAndInstall is the high-level workflow: walk the root chain,
// verify snapshot/targets/delegated metadata, check rollback, then
// install the payload and persist updated state.
func (c *Client) VerifyAndInstall(b *Bundle, st *state.State) error {
	newRoot, err := audit.ApplyRootChain(c.trustedRoot, b.RootChain)
	if err != nil {
		return err
	}
	if newRoot == nil {
		return fmt.Errorf("no trusted root after chain application")
	}

	for kid, k := range newRoot.Keys {
		c.keyRegistry[kid] = k
	}
	c.trustedRoot = newRoot

	if err := audit.VerifySnapshot(newRoot, b.Snapshot); err != nil {
		return fmt.Errorf("snapshot: %w", err)
	}

	if err := audit.VerifyTargets(newRoot, c.keyRegistry, b.Targets); err != nil {
		return fmt.Errorf("targets: %w", err)
	}

	current := audit.BuildDelegationTable(b.Targets.Signed)
	if c.delegationTable == nil {
		c.delegationTable = current
	} else {
		c.delegationTable.MergeNew(current)
	}

	delegatedSigned := b.SortedDelegated()
	for _, d := range delegatedSigned {
		if err := audit.VerifyDelegated(c.delegationTable, d); err != nil {
			return fmt.Errorf("delegated %s: %w", d.Signed.Name, err)
		}
	}

	delegatedPlain := make([]meta.Delegated, 0, len(delegatedSigned))
	for _, d := range delegatedSigned {
		delegatedPlain = append(delegatedPlain, d.Signed)
	}

	rollback := audit.RollbackState{
		LastRootVersion:        st.LastRootVersion,
		LastSnapshotVersion:    st.LastSnapshotVersion,
		LastTargetsVersion:     st.LastTargetsVersion,
		LastDelegationVersions: st.LastDelegationVersions,
	}
	if err := audit.CheckRollback(rollback, newRoot.Version, b.Snapshot.Signed, b.Targets.Signed, delegatedPlain); err != nil {
		return err
	}

	if expected := b.Snapshot.Signed.Meta["targets.json"]; expected != 0 && expected != b.Targets.Signed.Version {
		return fmt.Errorf("snapshot/targets version mismatch: snapshot says %d, targets file %d", expected, b.Targets.Signed.Version)
	}
	for _, d := range delegatedSigned {
		key := fmt.Sprintf("delegated/%s.json", d.Signed.Name)
		expected := b.Snapshot.Signed.Meta[key]
		if expected != 0 && expected != d.Signed.Version {
			return fmt.Errorf("snapshot/delegated %s version mismatch: snapshot says %d, file %d", d.Signed.Name, expected, d.Signed.Version)
		}
	}

	var primary *meta.Target
	var primaryDelegation string
	for _, d := range delegatedSigned {
		for i := range d.Signed.Targets {
			t := d.Signed.Targets[i]
			if primary != nil {
				return fmt.Errorf("multiple delegated targets are not supported in this client")
			}
			primary = &t
			primaryDelegation = d.Signed.Name
		}
	}
	if primary == nil {
		return fmt.Errorf("no delegated target found in bundle")
	}

	artifactPath := b.ArtifactPath(*primary)
	raw, err := os.ReadFile(artifactPath)
	if err != nil {
		return fmt.Errorf("read artifact: %w", err)
	}
	if len(raw) != primary.Length {
		return fmt.Errorf("artifact length mismatch")
	}
	sum := sha256.Sum256(raw)
	hexSum := hex.EncodeToString(sum[:])
	if hexSum != primary.SHA256 {
		return fmt.Errorf("%w: have %s, expected %s", ErrPayloadMismatch, hexSum, primary.SHA256)
	}

	newState := *st
	newState.LastRootVersion = newRoot.Version
	newState.LastSnapshotVersion = b.Snapshot.Signed.Version
	newState.LastTargetsVersion = b.Targets.Signed.Version
	if newState.LastDelegationVersions == nil {
		newState.LastDelegationVersions = map[string]int{}
	}
	delegVersions := map[string]int{}
	for k, v := range newState.LastDelegationVersions {
		delegVersions[k] = v
	}
	for _, d := range delegatedSigned {
		delegVersions[d.Signed.Name] = d.Signed.Version
	}
	newState.LastDelegationVersions = delegVersions
	newState.InstalledSHA256 = hexSum
	eventDeleg := map[string]int{}
	for _, d := range delegatedSigned {
		eventDeleg[d.Signed.Name] = d.Signed.Version
	}
	newState.Journal = append(append([]state.Event{}, st.Journal...), state.Event{
		RootVersion:        newRoot.Version,
		SnapshotVersion:    b.Snapshot.Signed.Version,
		TargetsVersion:     b.Targets.Signed.Version,
		DelegationVersions: eventDeleg,
		SHA256:             hexSum,
	})

	if err := os.MkdirAll(c.stateDir, 0o755); err != nil {
		return err
	}
	installPath := filepath.Join(c.stateDir, "installed.bin")
	if err := os.WriteFile(installPath, raw, 0o644); err != nil {
		return err
	}
	rawRoot, err := readRaw(filepath.Join(b.Dir, "root_chain.json"))
	if err == nil {
		_ = os.WriteFile(filepath.Join(c.stateDir, "last_chain.json"), rawRoot, 0o644)
	}
	if err := writeJSON(trustedRootPath(c.stateDir), newRoot); err != nil {
		return err
	}
	if err := writeJSON(delegationCachePath(c.stateDir), c.delegationTable); err != nil {
		return err
	}
	if err := state.Save(c.stateDir, &newState); err != nil {
		return err
	}
	*st = newState
	_ = primaryDelegation
	return nil
}

func writeJSON(path string, v any) error {
	raw, err := meta.Canonical(v)
	if err != nil {
		return err
	}
	return os.WriteFile(path, append(raw, '\n'), 0o644)
}

func readRaw(path string) ([]byte, error) {
	return os.ReadFile(path)
}
