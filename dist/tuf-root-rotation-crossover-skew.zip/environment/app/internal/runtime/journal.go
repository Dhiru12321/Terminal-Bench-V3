package runtime

import (
	"sort"

	"tufclient/internal/state"
)

// appendInstall builds a new journal entry from the verified bundle
// metadata.  Maps are sorted so the persisted journal serialization
// is byte-stable regardless of map iteration order.
func appendInstall(
	current []state.Event,
	rootVersion, snapshotVersion, targetsVersion int,
	delegationVersions map[string]int,
	sha string,
) []state.Event {
	keys := make([]string, 0, len(delegationVersions))
	for k := range delegationVersions {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	cv := make(map[string]int, len(keys))
	for _, k := range keys {
		cv[k] = delegationVersions[k]
	}
	out := append(state.CopyEvents(current), state.Event{
		RootVersion:        rootVersion,
		SnapshotVersion:    snapshotVersion,
		TargetsVersion:     targetsVersion,
		DelegationVersions: cv,
		SHA256:             sha,
	})
	return out
}
