// Package crypto wraps the standard library ed25519 implementation
// with helpers for hex-encoded keys and signatures and a stable key id
// derivation that the bundle generator and verifier both rely on.
package crypto

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/hex"
	"errors"
)

// DeriveKeyID returns the canonical key id for a hex-encoded ed25519
// public key.  Both bundlegen and tufverify must derive the same id
// from the same public material.
func DeriveKeyID(publicHex string) string {
	pub, err := hex.DecodeString(publicHex)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(pub)
	return hex.EncodeToString(sum[:16])
}

// DecodePublic parses a hex-encoded ed25519 public key.
func DecodePublic(publicHex string) (ed25519.PublicKey, error) {
	raw, err := hex.DecodeString(publicHex)
	if err != nil {
		return nil, err
	}
	if len(raw) != ed25519.PublicKeySize {
		return nil, errors.New("invalid ed25519 public key length")
	}
	return ed25519.PublicKey(raw), nil
}

// DecodeSignature parses a hex-encoded signature blob.
func DecodeSignature(sigHex string) ([]byte, error) {
	return hex.DecodeString(sigHex)
}

// Verify is a thin wrapper around ed25519.Verify so callers don't
// import the standard library directly.
func Verify(pub ed25519.PublicKey, message, sig []byte) bool {
	return ed25519.Verify(pub, message, sig)
}
