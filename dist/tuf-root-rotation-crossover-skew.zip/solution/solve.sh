#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/go/bin:/usr/local/bin:${PATH:-/usr/bin:/bin}"

cd /app

# Bug A: ApplyRootChain only self-verifies the new root; it must also
# verify the new root metadata against the previously trusted root's
# 'root' role keyids and threshold (crossover signature requirement).
cat > internal/audit/lineage.go <<'GO'
package audit

import (
	"errors"
	"fmt"

	"tufclient/internal/meta"
)

var ErrRootChain = errors.New("root chain not monotonic")

func ApplyRootChain(currentTrusted *meta.Root, chain []meta.RootSigned) (*meta.Root, error) {
	if len(chain) == 0 {
		if currentTrusted == nil {
			return nil, fmt.Errorf("%w: empty chain and no trusted root", ErrRootChain)
		}
		return currentTrusted, nil
	}

	trusted := currentTrusted
	for i, candidate := range chain {
		signedBytes, err := meta.Canonical(candidate.Signed)
		if err != nil {
			return nil, fmt.Errorf("root chain step %d: canonical encode: %w", i, err)
		}

		newRole, ok := candidate.Signed.Roles["root"]
		if !ok {
			return nil, fmt.Errorf("root chain step %d: new root metadata missing 'root' role", i)
		}
		newKeys := allowedKeys(newRole, candidate.Signed.Keys)
		if err := VerifyThreshold(signedBytes, candidate.Signatures, newKeys, newRole.Threshold); err != nil {
			return nil, fmt.Errorf("root chain step %d: self verification failed: %w", i, err)
		}

		if trusted == nil {
			next := candidate.Signed
			trusted = &next
			continue
		}

		if candidate.Signed.Version <= trusted.Version {
			continue
		}
		if candidate.Signed.Version != trusted.Version+1 {
			return nil, fmt.Errorf(
				"%w: chain step %d has version %d, expected up to %d or %d",
				ErrRootChain, i, candidate.Signed.Version, trusted.Version, trusted.Version+1,
			)
		}

		prevRole, ok := trusted.Roles["root"]
		if !ok {
			return nil, fmt.Errorf("root chain step %d: previous trusted root missing 'root' role", i)
		}
		prevKeys := allowedKeys(prevRole, trusted.Keys)
		if err := VerifyThreshold(signedBytes, candidate.Signatures, prevKeys, prevRole.Threshold); err != nil {
			return nil, fmt.Errorf("root chain step %d: crossover verification against previous root failed: %w", i, err)
		}

		next := candidate.Signed
		trusted = &next
	}
	return trusted, nil
}

func allowedKeys(role meta.Role, keys map[string]meta.PublicKey) map[string]meta.PublicKey {
	out := make(map[string]meta.PublicKey)
	for _, kid := range role.KeyIDs {
		if k, ok := keys[kid]; ok {
			out[kid] = k
		}
	}
	return out
}
GO

# Bug B: VerifyTargets must restrict signatures to keys listed in the
# active root's targets role, not the accumulated registry.
cat > internal/audit/targets.go <<'GO'
package audit

import (
	"fmt"

	"tufclient/internal/meta"
)

func VerifyTargets(active *meta.Root, _ map[string]meta.PublicKey, targets meta.TargetsSigned) error {
	role, ok := active.Roles["targets"]
	if !ok {
		return fmt.Errorf("targets role missing from active root")
	}
	allowed := allowedKeys(role, active.Keys)
	signedBytes, err := meta.Canonical(targets.Signed)
	if err != nil {
		return fmt.Errorf("targets canonical encode: %w", err)
	}
	return VerifyThreshold(signedBytes, targets.Signatures, allowed, role.Threshold)
}
GO

# Bug C: Delegation table must be rebuilt from the just-verified
# top-level targets on every run, not merged with a stale persisted
# cache.  Replace MergeNew with full replacement and stop persisting
# the cache.
cat > internal/audit/subscope.go <<'GO'
package audit

import (
	"encoding/json"
	"errors"
	"fmt"

	"tufclient/internal/meta"
)

var (
	jsonMarshal   = json.Marshal
	jsonUnmarshal = json.Unmarshal
)

var ErrUnknownDelegation = errors.New("unknown delegation")

type DelegationTable struct {
	roles map[string]meta.Delegation
}

func BuildDelegationTable(t meta.Targets) *DelegationTable {
	table := &DelegationTable{roles: map[string]meta.Delegation{}}
	for _, d := range t.Delegations {
		table.roles[d.Name] = d
	}
	return table
}

func (t *DelegationTable) Replace(other *DelegationTable) {
	if other == nil {
		t.roles = map[string]meta.Delegation{}
		return
	}
	t.roles = make(map[string]meta.Delegation, len(other.roles))
	for k, v := range other.roles {
		t.roles[k] = v
	}
}

func (t *DelegationTable) Lookup(name string) (meta.Delegation, bool) {
	d, ok := t.roles[name]
	return d, ok
}

func (t *DelegationTable) MarshalJSON() ([]byte, error) {
	if t == nil {
		return []byte("{}"), nil
	}
	return jsonMarshal(t.roles)
}

func (t *DelegationTable) UnmarshalJSON(data []byte) error {
	m := map[string]meta.Delegation{}
	if err := jsonUnmarshal(data, &m); err != nil {
		return err
	}
	t.roles = m
	return nil
}

func VerifyDelegated(table *DelegationTable, delegated meta.DelegatedSigned) error {
	d, ok := table.Lookup(delegated.Signed.Name)
	if !ok {
		return fmt.Errorf("%w: %s", ErrUnknownDelegation, delegated.Signed.Name)
	}
	signedBytes, err := meta.Canonical(delegated.Signed)
	if err != nil {
		return fmt.Errorf("delegated canonical encode: %w", err)
	}
	allowed := make(map[string]meta.PublicKey, len(d.KeyIDs))
	for _, kid := range d.KeyIDs {
		if k, ok := d.Keys[kid]; ok {
			allowed[kid] = k
		}
	}
	return VerifyThreshold(signedBytes, delegated.Signatures, allowed, d.Threshold)
}
GO

# Bug D: CheckRollback must enforce monotonic snapshot/targets/pkg
# versions even when the root version advances during a rotation.
cat > internal/audit/monotonic.go <<'GO'
package audit

import (
	"errors"
	"fmt"

	"tufclient/internal/meta"
)

var ErrRollback = errors.New("rollback detected")

type RollbackState struct {
	LastRootVersion        int
	LastSnapshotVersion    int
	LastTargetsVersion     int
	LastDelegationVersions map[string]int
}

func CheckRollback(
	state RollbackState,
	newRootVersion int,
	snapshot meta.Snapshot,
	targets meta.Targets,
	delegated []meta.Delegated,
) error {
	if newRootVersion < state.LastRootVersion {
		return fmt.Errorf("%w: root version %d < persisted %d",
			ErrRollback, newRootVersion, state.LastRootVersion)
	}
	if snapshot.Version < state.LastSnapshotVersion {
		return fmt.Errorf("%w: snapshot version %d < persisted %d",
			ErrRollback, snapshot.Version, state.LastSnapshotVersion)
	}
	if targets.Version < state.LastTargetsVersion {
		return fmt.Errorf("%w: targets version %d < persisted %d",
			ErrRollback, targets.Version, state.LastTargetsVersion)
	}
	for _, d := range delegated {
		prev := state.LastDelegationVersions[d.Name]
		if d.Version < prev {
			return fmt.Errorf("%w: delegation %q version %d < persisted %d",
				ErrRollback, d.Name, d.Version, prev)
		}
	}
	return nil
}
GO

# Stop persisting / re-using the stale delegation cache so the table
# is always rebuilt fresh.  Replace the MergeNew call with Replace.
python3 - <<'PY'
from pathlib import Path
p = Path("internal/runtime/runner.go")
src = p.read_text()
src = src.replace(
    'current := audit.BuildDelegationTable(b.Targets.Signed)\n\tif c.delegationTable == nil {\n\t\tc.delegationTable = current\n\t} else {\n\t\tc.delegationTable.MergeNew(current)\n\t}',
    'current := audit.BuildDelegationTable(b.Targets.Signed)\n\tif c.delegationTable == nil {\n\t\tc.delegationTable = current\n\t} else {\n\t\tc.delegationTable.Replace(current)\n\t}',
)
p.write_text(src)
PY

go build -trimpath -ldflags='-buildid= -s -w' -o /usr/local/bin/tufverify ./cmd/tufverify
echo "patched verifier and rebuilt /usr/local/bin/tufverify"
