#!/usr/bin/env bash
set -euo pipefail

# Oracle solution for arrow-shard-dict-delta-collision.
#
# The assembly module has three interacting defects:
#   1. It discovers shards via filesystem scan (`enumerate_arrow_files`)
#      instead of the manifest's `entry_paths`, so manifest order is
#      ignored.
#   2. The cross-shard `DictTracker::observe` is used to skip shards whose
#      anchor + cardinality collide with a previously seen shard, which
#      drops legitimate distinct shards whenever a verifier-generated
#      shard happens to share an anchor.
#   3. Vocabularies are appended naively (`accumulated_vocab.extend`) and
#      keys are copied unchanged, so every shard after the first decodes
#      into the prefix of the global vocab. The fix needs a dedup map and
#      remapped keys, plus schema metadata forwarding so the output
#      `shard.format` key is preserved.
#
# This oracle rewrites `assembly.rs` end-to-end with a manifest-driven,
# dedup-and-remap implementation and rebuilds the binary.

cd /app/environment

cat > src/assembly.rs <<'RUST'
use std::collections::HashMap;
use std::path::Path;
use std::sync::Arc;

use arrow_array::cast::AsArray;
use arrow_array::types::Int32Type;
use arrow_array::{
    Array, DictionaryArray, Int32Array, Int64Array, RecordBatch, StringArray,
};
use arrow_schema::{DataType, Field, Schema, SchemaRef};

use crate::error::ShardMergeError;
use crate::manifest::Manifest;
use crate::shard::{load_shard, LoadedShard};
use crate::writer::write_stream;

const TOKEN_FIELD: &str = "token";
const ROW_ID_FIELD: &str = "row_id";
const OUTPUT_DICT_ID: i64 = 0;

pub fn assemble_stream(manifest: &Manifest, out_path: &Path) -> Result<(), ShardMergeError> {
    let shard_paths = manifest.entry_paths();
    if shard_paths.is_empty() {
        return Err(ShardMergeError::EmptyManifest);
    }

    let mut loaded: Vec<LoadedShard> = Vec::with_capacity(shard_paths.len());
    for p in &shard_paths {
        loaded.push(load_shard(p)?);
    }

    let output_schema = build_output_schema(&loaded[0].schema)?;

    let mut global_vocab: Vec<String> = Vec::new();
    let mut global_index: HashMap<String, i32> = HashMap::new();
    let mut accumulated_keys: Vec<i32> = Vec::new();
    let mut accumulated_row_ids: Vec<i64> = Vec::new();

    for shard in &loaded {
        for batch in &shard.batches {
            let dict_col = batch.column(0).as_dictionary::<Int32Type>();
            let values = dict_col
                .values()
                .as_any()
                .downcast_ref::<StringArray>()
                .ok_or_else(|| {
                    ShardMergeError::Schema(format!(
                        "expected utf8 dictionary values in shard {}",
                        shard.source.display()
                    ))
                })?;
            let keys = dict_col.keys();
            for i in 0..keys.len() {
                if keys.is_null(i) {
                    return Err(ShardMergeError::Schema(
                        "null dictionary keys are not supported".into(),
                    ));
                }
                let local_idx = keys.value(i) as usize;
                if local_idx >= values.len() {
                    return Err(ShardMergeError::Schema(format!(
                        "key {} out of range for shard {}",
                        local_idx,
                        shard.source.display()
                    )));
                }
                let s = values.value(local_idx);
                let global_idx = match global_index.get(s) {
                    Some(&idx) => idx,
                    None => {
                        let idx = global_vocab.len() as i32;
                        global_vocab.push(s.to_string());
                        global_index.insert(s.to_string(), idx);
                        idx
                    }
                };
                accumulated_keys.push(global_idx);
            }
            let row_ids = batch
                .column(1)
                .as_any()
                .downcast_ref::<Int64Array>()
                .ok_or_else(|| {
                    ShardMergeError::Schema(format!(
                        "expected int64 row_id column in shard {}",
                        shard.source.display()
                    ))
                })?;
            for i in 0..row_ids.len() {
                accumulated_row_ids.push(row_ids.value(i));
            }
        }
    }

    let merged_batch = build_merged_batch(
        &output_schema,
        global_vocab,
        accumulated_keys,
        accumulated_row_ids,
    )?;

    write_stream(out_path, &output_schema, std::slice::from_ref(&merged_batch))?;
    Ok(())
}

fn build_output_schema(template: &SchemaRef) -> Result<SchemaRef, ShardMergeError> {
    let token_field = template
        .fields()
        .iter()
        .find(|f| f.name() == TOKEN_FIELD)
        .ok_or_else(|| ShardMergeError::Schema("missing token field".into()))?;
    let row_id_field = template
        .fields()
        .iter()
        .find(|f| f.name() == ROW_ID_FIELD)
        .ok_or_else(|| ShardMergeError::Schema("missing row_id field".into()))?;

    #[allow(deprecated)]
    let token = Field::new_dict(
        TOKEN_FIELD,
        DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Utf8)),
        token_field.is_nullable(),
        OUTPUT_DICT_ID,
        false,
    );
    let row_id = Field::new(ROW_ID_FIELD, DataType::Int64, row_id_field.is_nullable());

    let mut schema = Schema::new(vec![token, row_id]);
    schema = schema.with_metadata(template.metadata().clone());
    Ok(Arc::new(schema))
}

fn build_merged_batch(
    schema: &SchemaRef,
    vocab: Vec<String>,
    keys: Vec<i32>,
    row_ids: Vec<i64>,
) -> Result<RecordBatch, ShardMergeError> {
    let keys_arr = Int32Array::from(keys);
    let values_arr = Arc::new(StringArray::from(vocab));
    let dict = DictionaryArray::<Int32Type>::try_new(keys_arr, values_arr)?;
    let row_id_arr = Int64Array::from(row_ids);
    let batch = RecordBatch::try_new(schema.clone(), vec![Arc::new(dict), Arc::new(row_id_arr)])?;
    Ok(batch)
}
RUST

mkdir -p /app/bin /app/output
cargo build --release --locked
install -m 0755 /app/environment/target/release/shardmerge /app/bin/shardmerge

# Sanity: run on the default manifest to leave a fresh, correct output behind.
/app/bin/shardmerge \
    --manifest /app/environment/shards/manifest.json \
    --out /app/output/merged.arrow
