"""Behavioural checks for `/app/bin/shardmerge`.

Every test rebuilds the merger from `src/` and runs it against either the
checked-in shards or shards generated at verification time, then asserts
that the produced Arrow IPC stream decodes (via pyarrow) to the row
sequence implied by reading each shard independently.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

import pyarrow as pa
import pyarrow.ipc as ipc
import pytest

WORKSPACE = Path("/app/environment")
SHARDS_DIR = Path("/app/environment/shards")
DEFAULT_MANIFEST = Path("/app/environment/shards/manifest.json")
DEFAULT_OUTPUT = Path("/app/output/merged.arrow")
INSTALLED_BIN_PATH = "/app/bin/shardmerge"

DEFAULT_SHARDS = ["alpha", "beta", "gamma", "delta"]


# ---------------------------------------------------------------------------
# Build / session helpers
# ---------------------------------------------------------------------------


def _cargo() -> str:
    for c in ("/usr/local/cargo/bin/cargo", "/root/.cargo/bin/cargo"):
        if Path(c).exists():
            return c
    found = shutil.which("cargo")
    if found:
        return found
    raise AssertionError("cargo binary not found")


def _rebuild_from_source() -> None:
    """Force a clean release build of the merger and install it to /app/bin."""
    cargo = _cargo()
    subprocess.run(
        [
            cargo,
            "build",
            "--release",
            "--locked",
            "--manifest-path",
            "/app/environment/Cargo.toml",
        ],
        check=True,
    )
    built = Path("/app/environment/target/release/shardmerge")
    assert built.exists(), f"missing rebuilt binary at {built}"
    bin_path = Path(INSTALLED_BIN_PATH)
    bin_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(built, bin_path)
    os.chmod(bin_path, 0o755)


def _snapshot_shards() -> dict[str, bytes]:
    snap = {}
    for p in sorted(SHARDS_DIR.glob("shard_*.arrow")):
        snap[p.name] = p.read_bytes()
    snap["manifest.json"] = DEFAULT_MANIFEST.read_bytes()
    return snap


@pytest.fixture(scope="session", autouse=True)
def _build_and_protect_inputs():
    """Build the merger from source and protect the shard inputs."""
    _rebuild_from_source()
    magic = Path(INSTALLED_BIN_PATH).read_bytes()[:4]
    assert magic == b"\x7fELF", f"{INSTALLED_BIN_PATH} is not an ELF native binary"
    snapshot = _snapshot_shards()
    yield
    # Restore the original manifest in case a test mutated it.
    DEFAULT_MANIFEST.write_bytes(snapshot["manifest.json"])
    # Confirm shard files are unchanged.
    after = _snapshot_shards()
    for k in snapshot:
        if not k.startswith("shard_"):
            continue
        assert snapshot[k] == after.get(k), (
            f"shard input file {k} changed during the verifier run"
        )


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------


def _read_stream(path: Path) -> tuple[pa.Schema, list[str | None], list[int]]:
    with pa.OSFile(str(path), "rb") as src:
        reader = ipc.RecordBatchStreamReader(src)
        schema = reader.schema
        toks: list[str | None] = []
        rids: list[int] = []
        while True:
            try:
                batch = reader.read_next_batch()
            except StopIteration:
                break
            toks.extend(batch.column("token").to_pylist())
            rids.extend(batch.column("row_id").to_pylist())
    return schema, toks, rids


def _expected_from_shards(shard_order: list[str]) -> tuple[list[str], list[int]]:
    toks: list[str] = []
    rids: list[int] = []
    for name in shard_order:
        path = SHARDS_DIR / f"shard_{name}.arrow"
        _, t, r = _read_stream(path)
        toks.extend(t)
        rids.extend(r)
    return toks, rids


def _write_manifest(path: Path, names: list[str]) -> None:
    payload = {
        "shards": [{"name": n, "file": f"shard_{n}.arrow"} for n in names]
    }
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _run_merge(manifest: Path, out: Path) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        out.unlink()
    res = subprocess.run(
        [
            "/app/bin/shardmerge",
            "--manifest",
            str(manifest),
            "--out",
            str(out),
        ],
        capture_output=True,
        text=True,
    )
    if res.returncode != 0:
        raise AssertionError(
            f"shardmerge failed (rc={res.returncode})\n"
            f"stdout:\n{res.stdout}\nstderr:\n{res.stderr}"
        )
    assert out.exists(), f"shardmerge did not write {out}"


def _file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_clean_run_strings_match_per_shard_decode() -> None:
    """Default manifest: merged tokens equal the concatenation of per-shard decodes."""
    _write_manifest(DEFAULT_MANIFEST, DEFAULT_SHARDS)
    _run_merge(DEFAULT_MANIFEST, DEFAULT_OUTPUT)
    _, toks, rids = _read_stream(DEFAULT_OUTPUT)
    exp_toks, exp_rids = _expected_from_shards(DEFAULT_SHARDS)
    assert rids == exp_rids
    assert toks == exp_toks


def test_output_schema_is_dictionary_encoded_with_metadata() -> None:
    """Output keeps `token` dictionary<int32,utf8>, `row_id` int64, schema metadata."""
    _write_manifest(DEFAULT_MANIFEST, DEFAULT_SHARDS)
    _run_merge(DEFAULT_MANIFEST, DEFAULT_OUTPUT)
    schema, _, _ = _read_stream(DEFAULT_OUTPUT)
    token = schema.field("token")
    row_id = schema.field("row_id")
    assert token.type == pa.dictionary(pa.int32(), pa.string()), token.type
    assert row_id.type == pa.int64(), row_id.type
    md = schema.metadata or {}
    assert md.get(b"shard.format") == b"v1", md


def test_reverse_manifest_reorders_output_strings() -> None:
    """Reversing the manifest reverses the per-shard concatenation in the output."""
    reversed_order = list(reversed(DEFAULT_SHARDS))
    _write_manifest(DEFAULT_MANIFEST, reversed_order)
    _run_merge(DEFAULT_MANIFEST, DEFAULT_OUTPUT)
    _, toks, rids = _read_stream(DEFAULT_OUTPUT)
    exp_toks, exp_rids = _expected_from_shards(reversed_order)
    assert rids == exp_rids
    assert toks == exp_toks


def test_subset_manifest_uses_only_listed_shards() -> None:
    """Dropping a shard from the manifest must drop only its rows from output."""
    subset = ["beta", "delta"]
    _write_manifest(DEFAULT_MANIFEST, subset)
    _run_merge(DEFAULT_MANIFEST, DEFAULT_OUTPUT)
    _, toks, rids = _read_stream(DEFAULT_OUTPUT)
    exp_toks, exp_rids = _expected_from_shards(subset)
    assert rids == exp_rids
    assert toks == exp_toks


def test_rerun_produces_byte_identical_output() -> None:
    """Two successive merges on the same inputs must yield byte-identical files."""
    _write_manifest(DEFAULT_MANIFEST, DEFAULT_SHARDS)
    _run_merge(DEFAULT_MANIFEST, DEFAULT_OUTPUT)
    h1 = _file_sha256(DEFAULT_OUTPUT)
    _run_merge(DEFAULT_MANIFEST, DEFAULT_OUTPUT)
    h2 = _file_sha256(DEFAULT_OUTPUT)
    assert h1 == h2, "merger output is not deterministic across runs"


def test_two_independent_readers_see_same_strings() -> None:
    """Opening the merged file with two fresh stream readers yields the same strings."""
    _write_manifest(DEFAULT_MANIFEST, DEFAULT_SHARDS)
    _run_merge(DEFAULT_MANIFEST, DEFAULT_OUTPUT)
    _, toks1, rids1 = _read_stream(DEFAULT_OUTPUT)
    _, toks2, rids2 = _read_stream(DEFAULT_OUTPUT)
    assert toks1 == toks2
    assert rids1 == rids2
    exp_toks, exp_rids = _expected_from_shards(DEFAULT_SHARDS)
    assert toks1 == exp_toks
    assert rids1 == exp_rids


def test_row_count_equals_sum_of_shard_rows() -> None:
    """Total output rows equal the sum of input shard rows; no rows dropped or duplicated."""
    _write_manifest(DEFAULT_MANIFEST, DEFAULT_SHARDS)
    _run_merge(DEFAULT_MANIFEST, DEFAULT_OUTPUT)
    _, toks, _ = _read_stream(DEFAULT_OUTPUT)
    total = 0
    for name in DEFAULT_SHARDS:
        with pa.OSFile(str(SHARDS_DIR / f"shard_{name}.arrow"), "rb") as f:
            reader = ipc.RecordBatchStreamReader(f)
            while True:
                try:
                    batch = reader.read_next_batch()
                except StopIteration:
                    break
                total += batch.num_rows
    assert len(toks) == total


def _build_generated_shard(out_path: Path, vocab: list[str], rows: list[tuple[int, int]]) -> None:
    """Write a small Arrow IPC stream with one batch and dict_id=0 dictionary."""
    schema = pa.schema(
        [
            pa.field("token", pa.dictionary(pa.int32(), pa.string(), ordered=False))
                .with_metadata({b"ARROW:DICT:id": b"0"}),
            pa.field("row_id", pa.int64()),
        ],
        metadata={b"shard.format": b"v1"},
    )
    keys = pa.array([k for k, _ in rows], type=pa.int32())
    values = pa.array(vocab, type=pa.string())
    dict_arr = pa.DictionaryArray.from_arrays(keys, values)
    rid_arr = pa.array([r for _, r in rows], type=pa.int64())
    batch = pa.RecordBatch.from_arrays([dict_arr, rid_arr], schema=schema)
    options = ipc.IpcWriteOptions(emit_dictionary_deltas=True)
    with pa.OSFile(str(out_path), "wb") as sink:
        writer = ipc.RecordBatchStreamWriter(sink, schema, options=options)
        try:
            writer.write_batch(batch)
        finally:
            writer.close()


def test_extra_shard_with_anchor_collision_still_decodes_correctly() -> None:
    """An extra verifier-generated shard whose anchor matches another shard must not be dropped."""
    # Anchor "apple" matches shard_alpha; a tracker that dedups by (id, anchor,
    # cardinality) would otherwise skip this shard's rows.
    epsilon_path = SHARDS_DIR / "shard_epsilon.arrow"
    if epsilon_path.exists():
        epsilon_path.unlink()
    try:
        _build_generated_shard(
            epsilon_path,
            vocab=["apple", "echo", "ember"],
            rows=[(0, 5001), (1, 5002), (2, 5003), (1, 5004)],
        )
        order = DEFAULT_SHARDS + ["epsilon"]
        _write_manifest(DEFAULT_MANIFEST, order)
        _run_merge(DEFAULT_MANIFEST, DEFAULT_OUTPUT)
        _, toks, rids = _read_stream(DEFAULT_OUTPUT)
        exp_toks, exp_rids = _expected_from_shards(order)
        assert rids == exp_rids
        assert toks == exp_toks
    finally:
        if epsilon_path.exists():
            epsilon_path.unlink()


def test_overlapping_vocab_shard_does_not_corrupt_other_shards() -> None:
    """A generated shard whose vocab overlaps the alphabet shard must decode every row correctly."""
    omega_path = SHARDS_DIR / "shard_omega.arrow"
    if omega_path.exists():
        omega_path.unlink()
    try:
        _build_generated_shard(
            omega_path,
            vocab=["apple", "boat", "gulf", "dive"],
            rows=[(0, 6001), (1, 6002), (2, 6003), (3, 6004), (0, 6005), (3, 6006)],
        )
        order = ["alpha", "omega", "beta", "gamma", "delta"]
        _write_manifest(DEFAULT_MANIFEST, order)
        _run_merge(DEFAULT_MANIFEST, DEFAULT_OUTPUT)
        _, toks, rids = _read_stream(DEFAULT_OUTPUT)
        exp_toks, exp_rids = _expected_from_shards(order)
        assert rids == exp_rids
        assert toks == exp_toks
    finally:
        if omega_path.exists():
            omega_path.unlink()


def test_recovery_after_writing_garbage_output() -> None:
    """A garbage pre-existing output must be overwritten with a valid stream."""
    _write_manifest(DEFAULT_MANIFEST, DEFAULT_SHARDS)
    DEFAULT_OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    DEFAULT_OUTPUT.write_bytes(b"garbage-not-arrow")
    _run_merge(DEFAULT_MANIFEST, DEFAULT_OUTPUT)
    _, toks, rids = _read_stream(DEFAULT_OUTPUT)
    exp_toks, exp_rids = _expected_from_shards(DEFAULT_SHARDS)
    assert toks == exp_toks
    assert rids == exp_rids


def test_output_dictionary_values_have_no_duplicates() -> None:
    """The output dictionary must be deduplicated: each distinct string appears once."""
    _write_manifest(DEFAULT_MANIFEST, DEFAULT_SHARDS)
    _run_merge(DEFAULT_MANIFEST, DEFAULT_OUTPUT)
    with pa.OSFile(str(DEFAULT_OUTPUT), "rb") as src:
        reader = ipc.RecordBatchStreamReader(src)
        seen_vocab: set[str] = set()
        observed_strings: set[str] = set()
        while True:
            try:
                batch = reader.read_next_batch()
            except StopIteration:
                break
            dict_arr = batch.column("token")
            # dictionary().to_pylist() returns the unique values in the
            # dictionary block currently in effect for this batch.
            for v in dict_arr.dictionary.to_pylist():
                seen_vocab.add(v)
            for v in dict_arr.to_pylist():
                observed_strings.add(v)
    # The set of strings that show up in the materialised column must be
    # a subset of the dictionary values that the writer emitted.
    assert observed_strings <= seen_vocab
    # Sanity: at least every unique string from the inputs must appear.
    exp_toks, _ = _expected_from_shards(DEFAULT_SHARDS)
    assert set(exp_toks) <= observed_strings


def test_two_sequential_merges_with_different_orders_each_match_expected() -> None:
    """Switching from default to reversed manifest between runs produces matching outputs each time."""
    _write_manifest(DEFAULT_MANIFEST, DEFAULT_SHARDS)
    _run_merge(DEFAULT_MANIFEST, DEFAULT_OUTPUT)
    _, toks_fwd, rids_fwd = _read_stream(DEFAULT_OUTPUT)
    assert (toks_fwd, rids_fwd) == _expected_from_shards(DEFAULT_SHARDS)

    rev = list(reversed(DEFAULT_SHARDS))
    _write_manifest(DEFAULT_MANIFEST, rev)
    _run_merge(DEFAULT_MANIFEST, DEFAULT_OUTPUT)
    _, toks_rev, rids_rev = _read_stream(DEFAULT_OUTPUT)
    assert (toks_rev, rids_rev) == _expected_from_shards(rev)


def test_pyarrow_table_round_trip_preserves_values() -> None:
    """Reading the output as a pa.Table and re-extracting tokens preserves values."""
    _write_manifest(DEFAULT_MANIFEST, DEFAULT_SHARDS)
    _run_merge(DEFAULT_MANIFEST, DEFAULT_OUTPUT)
    with pa.OSFile(str(DEFAULT_OUTPUT), "rb") as src:
        reader = ipc.RecordBatchStreamReader(src)
        table = reader.read_all()
    toks = table.column("token").to_pylist()
    rids = table.column("row_id").to_pylist()
    exp_toks, exp_rids = _expected_from_shards(DEFAULT_SHARDS)
    assert toks == exp_toks
    assert rids == exp_rids
