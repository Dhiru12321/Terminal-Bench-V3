use std::fmt;
use std::io;

#[derive(Debug)]
pub enum ShardMergeError {
    Io(io::Error),
    Arrow(arrow_schema::ArrowError),
    Manifest(String),
    Schema(String),
    EmptyManifest,
}

impl fmt::Display for ShardMergeError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ShardMergeError::Io(e) => write!(f, "io error: {e}"),
            ShardMergeError::Arrow(e) => write!(f, "arrow error: {e}"),
            ShardMergeError::Manifest(s) => write!(f, "manifest error: {s}"),
            ShardMergeError::Schema(s) => write!(f, "schema error: {s}"),
            ShardMergeError::EmptyManifest => write!(f, "manifest contains no shards"),
        }
    }
}

impl std::error::Error for ShardMergeError {}

impl From<io::Error> for ShardMergeError {
    fn from(e: io::Error) -> Self {
        ShardMergeError::Io(e)
    }
}

impl From<arrow_schema::ArrowError> for ShardMergeError {
    fn from(e: arrow_schema::ArrowError) -> Self {
        ShardMergeError::Arrow(e)
    }
}

impl From<serde_json::Error> for ShardMergeError {
    fn from(e: serde_json::Error) -> Self {
        ShardMergeError::Manifest(format!("json: {e}"))
    }
}
