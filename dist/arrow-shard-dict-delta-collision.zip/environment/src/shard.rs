use std::fs::{self, File};
use std::path::{Path, PathBuf};

use arrow_array::RecordBatch;
use arrow_ipc::reader::StreamReader;
use arrow_schema::SchemaRef;

use crate::error::ShardMergeError;

pub struct LoadedShard {
    pub source: PathBuf,
    pub schema: SchemaRef,
    pub batches: Vec<RecordBatch>,
}

pub fn load_shard(path: &Path) -> Result<LoadedShard, ShardMergeError> {
    let file = File::open(path).map_err(|e| {
        ShardMergeError::Io(std::io::Error::new(
            e.kind(),
            format!("open shard {}: {e}", path.display()),
        ))
    })?;
    let reader = StreamReader::try_new(file, None)?;
    let schema = reader.schema();
    let mut batches = Vec::new();
    for batch in reader {
        batches.push(batch?);
    }
    Ok(LoadedShard {
        source: path.to_path_buf(),
        schema,
        batches,
    })
}

/// Enumerate `.arrow` files in a directory in lexicographic order.
///
/// This is the legacy discovery helper from when shards were laid out
/// alphabetically on disk; the project later introduced `manifest.json` to
/// pin a deterministic ingest order, but the helper is still used by parts
/// of the pipeline that haven't been switched over yet.
pub fn enumerate_arrow_files(dir: &Path) -> Result<Vec<PathBuf>, ShardMergeError> {
    let mut out = Vec::new();
    for entry in fs::read_dir(dir)? {
        let entry = entry?;
        let path = entry.path();
        if path.is_file()
            && path.extension().and_then(|x| x.to_str()) == Some("arrow")
        {
            out.push(path);
        }
    }
    out.sort();
    Ok(out)
}
