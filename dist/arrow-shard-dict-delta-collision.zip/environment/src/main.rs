use std::path::PathBuf;
use std::process::ExitCode;

use shardmerge::assembly::assemble_stream;
use shardmerge::manifest::Manifest;

const USAGE: &str = "\
shardmerge --manifest <path> --out <path>

Reads a shards manifest (JSON) listing per-shard Arrow IPC stream files in
ingest order, merges them into a single combined Arrow IPC stream, and writes
the result to the specified output file. The output's `token` column must
remain dictionary-encoded `dictionary<int32, utf8>`.
";

#[derive(Debug, Default)]
struct Args {
    manifest: Option<PathBuf>,
    out: Option<PathBuf>,
}

fn parse_args() -> Result<Args, String> {
    let mut args = Args::default();
    let raw: Vec<String> = std::env::args().skip(1).collect();
    let mut i = 0;
    while i < raw.len() {
        match raw[i].as_str() {
            "--manifest" => {
                i += 1;
                if i >= raw.len() {
                    return Err("--manifest expects a path".into());
                }
                args.manifest = Some(PathBuf::from(&raw[i]));
            }
            "--out" => {
                i += 1;
                if i >= raw.len() {
                    return Err("--out expects a path".into());
                }
                args.out = Some(PathBuf::from(&raw[i]));
            }
            "--help" | "-h" => {
                println!("{}", USAGE);
                std::process::exit(0);
            }
            other => return Err(format!("unrecognized argument: {other}")),
        }
        i += 1;
    }
    Ok(args)
}

fn main() -> ExitCode {
    let args = match parse_args() {
        Ok(a) => a,
        Err(e) => {
            eprintln!("shardmerge: {e}\n{USAGE}");
            return ExitCode::from(2);
        }
    };
    let manifest_path = match args.manifest {
        Some(p) => p,
        None => {
            eprintln!("shardmerge: --manifest is required\n{USAGE}");
            return ExitCode::from(2);
        }
    };
    let out_path = match args.out {
        Some(p) => p,
        None => {
            eprintln!("shardmerge: --out is required\n{USAGE}");
            return ExitCode::from(2);
        }
    };

    let manifest = match Manifest::load(&manifest_path) {
        Ok(m) => m,
        Err(e) => {
            eprintln!("shardmerge: failed to load manifest: {e}");
            return ExitCode::from(1);
        }
    };

    if let Err(e) = assemble_stream(&manifest, &out_path) {
        eprintln!("shardmerge: merge failed: {e}");
        return ExitCode::from(1);
    }

    eprintln!(
        "shardmerge: wrote {} from {} shards",
        out_path.display(),
        manifest.shards.len()
    );
    ExitCode::SUCCESS
}
