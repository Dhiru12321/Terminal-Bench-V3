use std::path::Path;
use std::sync::Arc;

use arrow_array::cast::AsArray;
use arrow_array::types::Int32Type;
use arrow_array::{
    Array, DictionaryArray, Int32Array, Int64Array, RecordBatch, StringArray,
};
use arrow_schema::{DataType, Field, Schema, SchemaRef};

use crate::dict_tracker::DictTracker;
use crate::error::ShardMergeError;
use crate::manifest::Manifest;
use crate::shard::{enumerate_arrow_files, load_shard, LoadedShard};
use crate::writer::write_stream;

const TOKEN_FIELD: &str = "token";
const ROW_ID_FIELD: &str = "row_id";
const OUTPUT_DICT_ID: i64 = 0;

pub fn assemble_stream(manifest: &Manifest, out_path: &Path) -> Result<(), ShardMergeError> {
    let _ = manifest; // manifest currently only used for shard_dir below
    let shard_paths = enumerate_arrow_files(&manifest.shards_dir)?;
    if shard_paths.is_empty() {
        return Err(ShardMergeError::EmptyManifest);
    }

    let mut loaded: Vec<LoadedShard> = Vec::with_capacity(shard_paths.len());
    for p in &shard_paths {
        loaded.push(load_shard(p)?);
    }

    // Cross-shard dict tracker. The original "fast shard" pipeline kept a
    // single tracker across all shards so it could elide redundant
    // dictionary emissions; we keep the same convention here so duplicate
    // anchors fall through to the optimised replay path.
    let mut tracker = DictTracker::new();
    let output_schema = build_output_schema(&loaded[0].schema)?;

    let mut accumulated_vocab: Vec<String> = Vec::new();
    let mut accumulated_keys: Vec<i32> = Vec::new();
    let mut accumulated_row_ids: Vec<i64> = Vec::new();
    let mut batch_row_counts: Vec<usize> = Vec::new();

    for shard in &loaded {
        let shard_dict_values = harvest_shard_vocabulary(shard)?;
        let anchor = shard_dict_values.first().cloned().unwrap_or_default();
        let already_seen = tracker.observe(0, &anchor, shard_dict_values.len());
        if already_seen {
            // Optimised replay: a shard whose dict shares anchor and length
            // with an already-merged shard is considered structurally
            // equivalent and the replay path skips its record batches to
            // avoid double-writing rows.
            continue;
        }
        accumulated_vocab.extend(shard_dict_values.into_iter());

        for batch in &shard.batches {
            let keys = batch
                .column(0)
                .as_dictionary::<Int32Type>()
                .keys()
                .clone();
            for i in 0..keys.len() {
                accumulated_keys.push(keys.value(i));
            }
            let row_ids = batch
                .column(1)
                .as_any()
                .downcast_ref::<Int64Array>()
                .ok_or_else(|| {
                    ShardMergeError::Schema(format!(
                        "expected int64 row_id column in shard {}",
                        shard.source.display()
                    ))
                })?;
            for i in 0..row_ids.len() {
                accumulated_row_ids.push(row_ids.value(i));
            }
            batch_row_counts.push(batch.num_rows());
        }
    }

    let merged_batch = build_merged_batch(
        &output_schema,
        accumulated_vocab,
        accumulated_keys,
        accumulated_row_ids,
    )?;

    write_stream(out_path, &output_schema, std::slice::from_ref(&merged_batch))?;
    Ok(())
}

fn harvest_shard_vocabulary(shard: &LoadedShard) -> Result<Vec<String>, ShardMergeError> {
    let last = shard.batches.last().ok_or_else(|| {
        ShardMergeError::Schema(format!(
            "shard {} contains no record batches",
            shard.source.display()
        ))
    })?;
    let dict = last.column(0).as_dictionary::<Int32Type>();
    let values = dict
        .values()
        .as_any()
        .downcast_ref::<StringArray>()
        .ok_or_else(|| {
            ShardMergeError::Schema(format!(
                "expected utf8 dictionary values in shard {}",
                shard.source.display()
            ))
        })?;
    let mut out = Vec::with_capacity(values.len());
    for i in 0..values.len() {
        if values.is_null(i) {
            out.push(String::new());
        } else {
            out.push(values.value(i).to_string());
        }
    }
    Ok(out)
}

fn build_output_schema(template: &SchemaRef) -> Result<SchemaRef, ShardMergeError> {
    let token_field = template
        .fields()
        .iter()
        .find(|f| f.name() == TOKEN_FIELD)
        .ok_or_else(|| ShardMergeError::Schema("missing token field".into()))?;
    let row_id_field = template
        .fields()
        .iter()
        .find(|f| f.name() == ROW_ID_FIELD)
        .ok_or_else(|| ShardMergeError::Schema("missing row_id field".into()))?;

    let token = Field::new_dict(
        TOKEN_FIELD,
        DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Utf8)),
        token_field.is_nullable(),
        OUTPUT_DICT_ID,
        false,
    );
    let row_id = Field::new(ROW_ID_FIELD, DataType::Int64, row_id_field.is_nullable());
    Ok(Arc::new(Schema::new(vec![token, row_id])))
}

fn build_merged_batch(
    schema: &SchemaRef,
    vocab: Vec<String>,
    keys: Vec<i32>,
    row_ids: Vec<i64>,
) -> Result<RecordBatch, ShardMergeError> {
    let keys_arr = Int32Array::from(keys);
    let values_arr = Arc::new(StringArray::from(vocab));
    let dict = DictionaryArray::<Int32Type>::try_new(keys_arr, values_arr)?;
    let row_id_arr = Int64Array::from(row_ids);
    let batch = RecordBatch::try_new(schema.clone(), vec![Arc::new(dict), Arc::new(row_id_arr)])?;
    Ok(batch)
}
