use std::fs;
use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};

use crate::error::ShardMergeError;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ManifestEntry {
    pub name: String,
    pub file: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Manifest {
    pub shards: Vec<ManifestEntry>,
    #[serde(skip)]
    pub shards_dir: PathBuf,
}

impl Manifest {
    pub fn load(path: &Path) -> Result<Self, ShardMergeError> {
        let text = fs::read_to_string(path).map_err(|e| {
            ShardMergeError::Manifest(format!("read {}: {e}", path.display()))
        })?;
        let mut m: Manifest = serde_json::from_str(&text)?;
        m.shards_dir = path.parent().unwrap_or(Path::new(".")).to_path_buf();
        if m.shards.is_empty() {
            return Err(ShardMergeError::EmptyManifest);
        }
        Ok(m)
    }

    pub fn entry_paths(&self) -> Vec<PathBuf> {
        self.shards
            .iter()
            .map(|e| self.shards_dir.join(&e.file))
            .collect()
    }
}
