use std::fs::{self, File};
use std::path::Path;

use arrow_array::RecordBatch;
use arrow_ipc::writer::{IpcWriteOptions, StreamWriter};
use arrow_schema::SchemaRef;

use crate::error::ShardMergeError;

/// Writes the merged record batches as an Arrow IPC stream.
///
/// The output directory is created if it does not exist. The writer uses the
/// default IPC stream options so the resulting bytes are accepted by any
/// standard Arrow IPC stream reader (e.g. `pyarrow.ipc.open_stream`).
pub fn write_stream(
    path: &Path,
    schema: &SchemaRef,
    batches: &[RecordBatch],
) -> Result<(), ShardMergeError> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }
    let file = File::create(path)?;
    let opts = IpcWriteOptions::default();
    let mut writer = StreamWriter::try_new_with_options(file, schema.as_ref(), opts)?;
    for batch in batches {
        writer.write(batch)?;
    }
    writer.finish()?;
    Ok(())
}
