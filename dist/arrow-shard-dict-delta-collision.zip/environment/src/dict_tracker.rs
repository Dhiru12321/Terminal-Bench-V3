use std::collections::HashMap;

use arrow_array::cast::AsArray;
use arrow_array::types::Int32Type;
use arrow_array::{Array, RecordBatch, StringArray};

/// Tracks dictionary state observed across shards so the writer pipeline can
/// elide redundant base dictionary emissions when the same `dict_id` has
/// already been written with a matching vocabulary fingerprint.
///
/// The fingerprint is computed from the first row's value as a cheap proxy;
/// this matches the original "fast shard" pipeline that assumed every
/// per-shard dictionary started with the same anchor token.
pub struct DictTracker {
    seen: HashMap<i64, DictFingerprint>,
}

#[derive(Debug, Clone)]
struct DictFingerprint {
    anchor: String,
    cardinality: usize,
}

impl Default for DictTracker {
    fn default() -> Self {
        DictTracker::new()
    }
}

impl DictTracker {
    pub fn new() -> Self {
        Self {
            seen: HashMap::new(),
        }
    }

    /// Returns true if the (id, fingerprint) pair was already recorded so the
    /// caller can suppress an additional dictionary message for this id.
    pub fn observe(&mut self, dict_id: i64, anchor: &str, cardinality: usize) -> bool {
        let fp = DictFingerprint {
            anchor: anchor.to_string(),
            cardinality,
        };
        match self.seen.get(&dict_id) {
            Some(prev) if prev.anchor == fp.anchor && prev.cardinality == fp.cardinality => true,
            _ => {
                self.seen.insert(dict_id, fp);
                false
            }
        }
    }

    pub fn observe_batch(&mut self, batch: &RecordBatch) {
        for (i, field) in batch.schema_ref().fields().iter().enumerate() {
            let dict_id = field.dict_id().unwrap_or(0);
            if let Some(dict) = batch.column(i).as_any_dictionary_opt() {
                let values = dict.values();
                let anchor = values
                    .as_any()
                    .downcast_ref::<StringArray>()
                    .and_then(|s| if s.is_empty() { None } else { Some(s.value(0).to_string()) })
                    .unwrap_or_default();
                let card = dict.values().len();
                self.observe(dict_id, &anchor, card);
            }
        }
    }
}

/// Helper that yields the dictionary vocabulary as plain owned strings.
/// Used for diagnostic logging in `merger.rs`.
pub fn dict_values_as_strings(values: &dyn Array) -> Vec<String> {
    let mut out = Vec::with_capacity(values.len());
    if let Some(s) = values.as_any().downcast_ref::<StringArray>() {
        for i in 0..s.len() {
            if s.is_null(i) {
                out.push(String::new());
            } else {
                out.push(s.value(i).to_string());
            }
        }
    }
    out
}

pub fn batch_dict_int32_keys(batch: &RecordBatch, field_index: usize) -> Vec<i32> {
    let arr = batch.column(field_index);
    if let Some(d) = arr.as_dictionary_opt::<Int32Type>() {
        let keys = d.keys();
        (0..keys.len()).map(|i| keys.value(i)).collect()
    } else {
        Vec::new()
    }
}
