# Arrow IPC shard notes

A reminder of how the upstream producer writes per-shard streams, so you
have the bits handy while wiring the merger.

- Each shard is an Arrow IPC *stream* (no file footer, no random access).
- The producer always assigns `dict_id = 0` to the single dictionary field
  in a shard. This is fine for a stand-alone shard because there is only
  one logical dictionary; the *id* is opaque to the producer.
- A shard may emit any mixture of base dictionary messages and delta
  dictionary messages before record batches that reference them. A delta
  message carries only the *new* dictionary entries appended after the
  last vocabulary snapshot for that id.
- Two shards do not coordinate their dictionaries. Two shards with the
  same `dict_id` will almost always carry disjoint vocabularies.

When several shards are concatenated into one downstream stream the
output is also an Arrow IPC stream, so any standard Arrow IPC stream
reader must be able to recover the original string values from the
on-disk indices. Doing that requires choosing a single dictionary-id
space for the output (whether by re-keying per shard or by collapsing
to a global vocabulary) and making sure each record batch's keys index
into the vocabulary that is live for that batch in the output stream.

## Debugging tips

- `tools/inspect_stream.py <file.arrow>` dumps the message sequence
  (schema, dict id, delta flag, batch sizes) for any Arrow IPC stream
  produced by either the shards or the merger.
- The pyarrow reader treats successive base dict messages with the same
  id as full replacements; delta messages with the same id are
  appended. Reader behaviour does not change based on the writer's
  intent, only on the on-wire flag.
