# Per-shard file format

Each `shards/shard_*.arrow` file is an Arrow IPC stream produced by
the upstream ingest process. The on-wire shape of a single shard is:

```
Schema
[ Dictionary message {id=0, isDelta=false, values=[...]} ]
[ Dictionary message {id=0, isDelta=true,  values=[...]} ]?
[ Dictionary message {id=0, isDelta=true,  values=[...]} ]?
...
RecordBatch  (refers to dict_id=0)
RecordBatch  (refers to dict_id=0)
...
EndOfStream
```

Two important properties:

- The producer always reuses `dict_id = 0`. Different shards therefore
  encode different vocabularies under the same id, and consumers that
  pull from more than one shard must re-namespace before writing the
  merged output.
- A delta dictionary message only carries the *new* entries appended
  on top of the previous (base or delta) dictionary message for the
  same id. Re-reading a shard in isolation with a standard Arrow IPC
  stream reader yields the correct materialised strings; the producer
  relies on that property and ships shards without any side-channel
  metadata.

## Manifest

`shards/manifest.json` records the producer-intended ingest order:

```json
{
  "shards": [
    {"name": "alpha", "file": "shard_alpha.arrow"},
    {"name": "beta",  "file": "shard_beta.arrow"},
    {"name": "gamma", "file": "shard_gamma.arrow"},
    {"name": "delta", "file": "shard_delta.arrow"}
  ]
}
```

The producer guarantees the `file` entries correspond to files in this
directory. The merger must walk the `shards` array in order; the
filesystem listing of `shards/` is not authoritative because the
filenames sort lexicographically (alpha, beta, delta, gamma) and that
differs from the producer-intended ingest order.
