# shardmerge pipeline

`shardmerge` is the per-batch ingest worker that turns a set of upstream
shard files into the single consolidated Arrow IPC stream that the analytics
layer consumes.

## Inputs

- `shards/manifest.json` lists each shard's logical `name` and the on-disk
  `file` in producer-intended ingest order. The producer guarantees this
  order matches the temporal partitioning of the upstream feed; the merger
  must respect it.
- `shards/shard_*.arrow` are per-shard Arrow IPC stream files. Each shard
  carries one dictionary-encoded `token` column (`dictionary<int32, utf8>`)
  and a paired `row_id` int64 column. Shards are produced independently and
  re-use the same on-the-wire `dict_id` so the producer can pipeline writes
  without coordination.

## Output

- `/app/output/merged.arrow` is a single Arrow IPC stream. The token column
  stays dictionary-encoded; schema-level metadata is forwarded from the
  shard schemas (the producer sets `shard.format = v1`).

## Re-running

The merger is intended to be deterministic. Re-running it against the same
shards (and the same `manifest.json`) should produce byte-identical output.
The shard files under `shards/` are read-only inputs and the merger must
not mutate them. The output stream must be readable from a freshly opened
reader without referring back to the merger's in-memory state.

## Build

```
cargo build --release --locked --manifest-path /app/environment/Cargo.toml
```

produces `/app/environment/target/release/shardmerge`. The `--locked` flag
pins the dependency graph to `Cargo.lock` so the verifier and the agent
both see the same arrow-rs build. The packaged binary at
`/app/bin/shardmerge` is installed at image build time from
`/app/environment/target/release/shardmerge`; re-run `cargo build` and copy
or symlink the new artefact into `/app/bin/` after changing source. The
Rust toolchain is provided by the base image at `/usr/local/cargo/bin/cargo`
(also available as `/root/.cargo/bin/cargo` on developer images).

The pytest verifier emits a CTRF JSON report (`--ctrf`) into
`/logs/verifier/ctrf.json`; that is the standard Terminus runner contract
and does not need to be configured by the task.

## Verifier expectations

The verifier regenerates `/app/output/merged.arrow` for every test and uses
several manifests against the same shard set:

- the canonical `manifest.json` (alpha, beta, gamma, delta);
- a reversed manifest (delta, gamma, beta, alpha);
- a subset manifest (beta, delta);
- the canonical manifest extended with an additional verifier-generated
  shard, used under either the suffix name `epsilon` (anchor "apple",
  same dict_id) or `omega` (vocabulary that overlaps several existing
  shards). The corresponding files
  `/app/environment/shards/shard_epsilon.arrow` and
  `/app/environment/shards/shard_omega.arrow` are written into
  `/app/environment/shards/` for the duration of a single test and
  deleted on teardown.

For every variant the verifier compares the merged output to the
per-shard pyarrow decode of the manifest's ingest order. One regression
test additionally writes the literal byte string `garbage-not-arrow`
over the previous `/app/output/merged.arrow` to confirm the merger
overwrites a stale, invalid output rather than appending to or relying
on its contents. Determinism is verified by re-running the merger
twice and asserting that the two outputs have identical `sha256`
digests (the verifier imports `hashlib` for this comparison).

