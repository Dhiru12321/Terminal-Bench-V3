# Dictionary-encoding rules for the merged stream

The merged Arrow IPC stream is consumed by downstream tools that assume:

1. The `token` column is dictionary-encoded with `int32` keys and `utf8`
   values, and that encoding survives a round-trip through any standard
   Arrow IPC stream reader.
2. The materialised string for row `i` of the merged stream equals the
   materialised string for the corresponding row of the source shard,
   read with a standard Arrow IPC stream reader applied to that shard
   in isolation.
3. The materialised string is stable across multiple readers of the same
   merged file: opening the file twice in the same process, or once in
   pyarrow and once in any other Arrow-compatible reader, must yield the
   same sequence of strings.
4. The `row_id` int64 column is preserved value-for-value from each
   shard, in manifest order. Row ids are unique across the test corpus.

## What "preserved" means for schema metadata

The shard schemas carry a single schema-level metadata pair,
`shard.format = v1`. The merged stream's schema metadata must contain
the same key/value pair. Field-level metadata is not required to round
trip (different writers handle dictionary-id metadata differently, and
the downstream tools never read it).

## Vocabulary and key layout

The merged stream's dictionary is free to be any deduplicated superset
of the per-shard vocabularies. The dictionary need not preserve any
particular ordering, as long as the keys in the record batches index
into the live dictionary in such a way that decoded strings match the
per-shard truth.

## Reading model

Downstream readers use only the public Arrow IPC stream API. They do
not seek inside the stream and they do not maintain any state across
files. The merger must therefore make the strings recoverable from the
on-wire bytes alone; nothing about the merger's internal bookkeeping
is visible to a downstream reader.
