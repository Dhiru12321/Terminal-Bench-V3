# shardmerge environment

This directory contains the merger source for the shard-IPC pipeline.

```
.
├── Cargo.toml           crate manifest
├── Cargo.lock           pinned dependencies
├── Dockerfile           build/runtime image
├── README.md            this file
├── docs/                pipeline notes (see PIPELINE.md and IPC_NOTES.md)
├── shards/              read-only per-shard Arrow IPC stream fixtures
│   ├── manifest.json    producer-intended ingest order
│   └── shard_*.arrow    per-shard IPC streams (one dict-encoded token column)
├── src/                 Rust source for the `shardmerge` binary
│   ├── assembly.rs      end-to-end multi-shard assembly logic
│   ├── dict_tracker.rs  cross-shard dictionary id/anchor bookkeeping
│   ├── error.rs         error types
│   ├── lib.rs           module wiring
│   ├── main.rs          CLI entrypoint
│   ├── manifest.rs      manifest loader
│   ├── shard.rs         per-shard reader and on-disk discovery helpers
│   └── writer.rs        Arrow IPC stream writer
└── tools/
    ├── gen_shards.py    reference shard producer (writes shards/*.arrow)
    └── inspect_stream.py debugging helper that dumps IPC message sequence
```

Build the binary with `cargo build --release` from this directory; the
resulting executable lives at `target/release/shardmerge` and is also
installed to `/app/bin/shardmerge` at image build time.

Invoke as:

```
shardmerge --manifest /app/environment/shards/manifest.json \
           --out /app/output/merged.arrow
```
