#!/usr/bin/env python3
"""Dump the message sequence of an Arrow IPC stream for debugging.

Usage:
    inspect_stream.py <path.arrow>

The script walks the stream message-by-message and prints schema, dict
ids, delta flags, batch row counts, and decoded sample values for each
batch. It uses only the public pyarrow IPC API so the output reflects
what any standard reader sees on the wire.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pyarrow as pa
import pyarrow.ipc as ipc


def dump_stream(path: Path) -> None:
    with pa.OSFile(str(path), "rb") as src:
        reader = ipc.RecordBatchStreamReader(src)
        print(f"=== {path.name} ===")
        print(f"schema: {reader.schema}")
        idx = 0
        while True:
            try:
                batch = reader.read_next_batch()
            except StopIteration:
                break
            sample_token = batch.column("token").to_pylist()
            sample_rowid = batch.column("row_id").to_pylist()
            print(
                f"  batch[{idx}] rows={batch.num_rows} "
                f"tokens={sample_token[:6]} row_ids={sample_rowid[:6]}"
            )
            idx += 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("path", type=Path)
    args = parser.parse_args()
    if not args.path.is_file():
        print(f"not a file: {args.path}", file=sys.stderr)
        return 1
    dump_stream(args.path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
