#!/usr/bin/env python3
"""Print the resolved shard manifest in a human-friendly table.

Usage:
    dump_manifest.py [<manifest.json>]

Defaults to `../shards/manifest.json` relative to this script. The output
shows each shard's name, file, row count, and dictionary cardinality so
you can quickly compare the producer-intended order against what
actually lives on disk.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pyarrow as pa
import pyarrow.ipc as ipc


def _summarise_shard(path: Path) -> tuple[int, int, list[str], str]:
    rows = 0
    seen_dict: set[str] = set()
    materialised: list[str] = []
    with pa.OSFile(str(path), "rb") as src:
        reader = ipc.RecordBatchStreamReader(src)
        while True:
            try:
                batch = reader.read_next_batch()
            except StopIteration:
                break
            rows += batch.num_rows
            dict_arr = batch.column("token")
            for v in dict_arr.dictionary.to_pylist():
                seen_dict.add(v)
            materialised.extend(dict_arr.to_pylist()[:3])
    digest = hashlib.sha256(path.read_bytes()).hexdigest()[:12]
    return rows, len(seen_dict), materialised[:6], digest


def main() -> int:
    default = Path(__file__).resolve().parent.parent / "shards" / "manifest.json"
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", nargs="?", type=Path, default=default)
    args = parser.parse_args()
    payload = json.loads(args.manifest.read_text(encoding="utf-8"))
    base = args.manifest.parent
    print(f"{'name':<10} {'file':<26} {'rows':>6} {'vocab':>6}  {'sha256':<14}  sample")
    print("-" * 88)
    for entry in payload["shards"]:
        path = base / entry["file"]
        rows, vocab, sample, digest = _summarise_shard(path)
        sample_str = " ".join(sample)
        print(f"{entry['name']:<10} {entry['file']:<26} {rows:>6} {vocab:>6}  {digest:<14}  {sample_str}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
