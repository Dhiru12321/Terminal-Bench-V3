#!/usr/bin/env python3
"""Compare the merger output against per-shard decodes.

Usage:
    check_roundtrip.py [--manifest <path>] [--output <path>]

Reads the merged Arrow IPC stream and the per-shard Arrow IPC streams
referenced in the manifest, decoding both with a standard pyarrow
stream reader. Reports the first row where the merged output disagrees
with the per-shard concatenation (or "OK" if every row matches).
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pyarrow as pa
import pyarrow.ipc as ipc


def _read_stream(path: Path) -> tuple[list[str], list[int]]:
    toks: list[str] = []
    rids: list[int] = []
    with pa.OSFile(str(path), "rb") as src:
        reader = ipc.RecordBatchStreamReader(src)
        while True:
            try:
                batch = reader.read_next_batch()
            except StopIteration:
                break
            toks.extend(batch.column("token").to_pylist())
            rids.extend(batch.column("row_id").to_pylist())
    return toks, rids


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--manifest",
        type=Path,
        default=Path("/app/environment/shards/manifest.json"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("/app/output/merged.arrow"),
    )
    args = parser.parse_args()
    if not args.manifest.is_file():
        print(f"manifest not found: {args.manifest}")
        return 2
    if not args.output.is_file():
        print(f"output not found: {args.output}")
        return 2

    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    base = args.manifest.parent
    exp_toks: list[str] = []
    exp_rids: list[int] = []
    for entry in manifest["shards"]:
        shard_path = base / entry["file"]
        toks, rids = _read_stream(shard_path)
        exp_toks.extend(toks)
        exp_rids.extend(rids)

    got_toks, got_rids = _read_stream(args.output)

    if len(got_toks) != len(exp_toks):
        print(f"FAIL: row count mismatch (got={len(got_toks)} expected={len(exp_toks)})")
        return 1
    for i, (gt, et, gr, er) in enumerate(zip(got_toks, exp_toks, got_rids, exp_rids)):
        if gt != et or gr != er:
            print(
                f"FAIL: row {i} mismatch:\n"
                f"  got      token={gt!r} row_id={gr}\n"
                f"  expected token={et!r} row_id={er}"
            )
            return 1
    print(f"OK: {len(got_toks)} rows match per-shard decode")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
