#!/usr/bin/env python3
"""Generate the per-shard Arrow IPC stream fixtures used by the merger pipeline.

Every shard writes a single dictionary-encoded ``token`` column and a paired
``row_id`` int64 column. Each shard uses the same on-the-wire ``dict_id`` (0)
- this is the upstream producer's contract - so vocabularies collide across
shards if the merger does not re-key them globally.

This script is the reference producer; the .arrow files it emits are
committed to ``shards/`` as read-only inputs. Re-running it overwrites those
files with byte-identical output (it is deterministic).

The companion ``manifest.json`` (also committed) lists the shards in the
intended ingest order, which is *not* the same as filesystem alphabetical
order, so order-only bugs surface immediately.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pyarrow as pa
import pyarrow.ipc as ipc

OUTPUT_DICT_ID = 0


def _dict_field(name: str, dict_id: int) -> pa.Field:
    field = pa.field(name, pa.dictionary(pa.int32(), pa.string(), ordered=False))
    return field.with_metadata({b"ARROW:DICT:id": str(dict_id).encode("utf-8")})


def _row_field(name: str) -> pa.Field:
    return pa.field(name, pa.int64())


def _schema() -> pa.Schema:
    return pa.schema(
        [
            _dict_field("token", OUTPUT_DICT_ID),
            _row_field("row_id"),
        ],
        metadata={b"shard.format": b"v1"},
    )


def _make_batch(schema: pa.Schema, dict_values: list[str], indices: list[int],
                row_ids: list[int]) -> pa.RecordBatch:
    keys = pa.array(indices, type=pa.int32())
    values = pa.array(dict_values, type=pa.string())
    dict_arr = pa.DictionaryArray.from_arrays(keys, values)
    rid = pa.array(row_ids, type=pa.int64())
    return pa.RecordBatch.from_arrays([dict_arr, rid], schema=schema)


def _write_stream(out_path: Path, schema: pa.Schema, batches: list[pa.RecordBatch]) -> None:
    options = ipc.IpcWriteOptions(emit_dictionary_deltas=True)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with pa.OSFile(str(out_path), "wb") as sink:
        writer = ipc.RecordBatchStreamWriter(sink, schema, options=options)
        try:
            for b in batches:
                writer.write_batch(b)
        finally:
            writer.close()


def build_shard_alpha(schema: pa.Schema) -> list[pa.RecordBatch]:
    """alpha: base dict of 2 anchors, delta adds 2 more, two batches."""
    base = ["apple", "ant"]
    delta_added = ["axiom", "atom"]
    full = base + delta_added
    b1 = _make_batch(schema, base, [0, 1, 0, 1], [1001, 1002, 1003, 1004])
    b2 = _make_batch(schema, full, [2, 3, 0, 2], [1005, 1006, 1007, 1008])
    return [b1, b2]


def build_shard_beta(schema: pa.Schema) -> list[pa.RecordBatch]:
    """beta: single base dict, one batch referencing all entries."""
    vocab = ["bear", "boat", "bell", "berry", "bay"]
    b1 = _make_batch(schema, vocab, [0, 4, 2, 1, 3, 0], [2001, 2002, 2003, 2004, 2005, 2006])
    return [b1]


def build_shard_gamma(schema: pa.Schema) -> list[pa.RecordBatch]:
    """gamma: base + 2 successive deltas, one batch per dictionary stage."""
    stage1 = ["gulf"]
    stage2 = stage1 + ["ghost"]
    stage3 = stage2 + ["garden"]
    b1 = _make_batch(schema, stage1, [0, 0, 0], [3001, 3002, 3003])
    b2 = _make_batch(schema, stage2, [1, 0, 1], [3004, 3005, 3006])
    b3 = _make_batch(schema, stage3, [2, 1, 0], [3007, 3008, 3009])
    return [b1, b2, b3]


def build_shard_delta(schema: pa.Schema) -> list[pa.RecordBatch]:
    """delta: base dict of 3, one delta adding 3, two batches."""
    base = ["dive", "drum", "dance"]
    full = base + ["dawn", "dock", "dust"]
    b1 = _make_batch(schema, base, [0, 1, 2, 0], [4001, 4002, 4003, 4004])
    b2 = _make_batch(schema, full, [3, 4, 5, 2], [4005, 4006, 4007, 4008])
    return [b1, b2]


SHARD_BUILDERS = {
    "alpha": build_shard_alpha,
    "beta": build_shard_beta,
    "gamma": build_shard_gamma,
    "delta": build_shard_delta,
}

# Manifest ingest order is the producer-intended order (greek alphabet),
# which differs from the alphabetical filesystem ordering of the file
# names (alpha < beta < delta < gamma).
MANIFEST_ORDER = ["alpha", "beta", "gamma", "delta"]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--out-dir",
        default=str(Path(__file__).resolve().parent.parent / "shards"),
    )
    args = parser.parse_args()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    schema = _schema()
    for name in SHARD_BUILDERS:
        batches = SHARD_BUILDERS[name](schema)
        path = out_dir / f"shard_{name}.arrow"
        _write_stream(path, schema, batches)
        print(f"wrote {path} ({len(batches)} batches)")

    manifest = {
        "shards": [
            {"name": name, "file": f"shard_{name}.arrow"} for name in MANIFEST_ORDER
        ]
    }
    manifest_path = out_dir / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=False) + "\n",
        encoding="utf-8",
    )
    print(f"wrote {manifest_path}")


if __name__ == "__main__":
    main()
